package net.safix.esotericvaccum.client.rendering.meshing;

import net.safix.esotericvaccum.client.util.BlockModelData;

public interface IFaceWriteOrder {
	void setUV(float minU, float minV, float maxU, float maxV);
	void vertexOne(BlockModelData modelData, int color);
	void vertexTwo(BlockModelData modelData, int color);
	void vertexThree(BlockModelData modelData, int color);
	void vertexFour(BlockModelData modelData, int color);
}

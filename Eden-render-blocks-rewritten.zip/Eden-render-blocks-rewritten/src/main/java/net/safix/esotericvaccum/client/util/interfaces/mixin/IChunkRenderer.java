package net.safix.esotericvaccum.client.util.interfaces.mixin;

import net.safix.esotericvaccum.client.gl.GlVertexBuffer;

public interface IChunkRenderer {
	GlVertexBuffer getBuffer(int renderPass);
	GlVertexBuffer getSolidBuffer();
	GlVertexBuffer getTranslucentBuffer();
	int getVertices();
	int getFaces();
}

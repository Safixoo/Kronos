package net.safix.esotericvaccum;

import net.fabricmc.api.ModInitializer;
import net.safix.esotericvaccum.client.BlockCacheData;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GLContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import turniplabs.halplibe.util.GameStartEntrypoint;
import turniplabs.halplibe.util.RecipeEntrypoint;


public class Eden implements ModInitializer, GameStartEntrypoint, RecipeEntrypoint {
    public static final String MOD_ID = "Eden";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static boolean supportDirectStateAccess;

    @Override
    public void onInitialize() {
		BlockCacheData.cacheValues();
    }

	@Override public void beforeGameStart() {}
	@Override
	public void afterGameStart() {
		ContextCapabilities cap = GLContext.getCapabilities();
		supportDirectStateAccess = cap.GL_EXT_direct_state_access;
	}
	@Override public void onRecipesReady() {}
	@Override public void initNamespaces() {}
}

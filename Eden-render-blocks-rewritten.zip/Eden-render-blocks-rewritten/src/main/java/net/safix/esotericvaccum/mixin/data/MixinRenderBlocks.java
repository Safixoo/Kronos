package net.safix.esotericvaccum.mixin.data;

import net.minecraft.client.render.RenderBlockCache;
import net.minecraft.client.render.RenderBlocks;
import net.minecraft.client.render.block.color.BlockColorDispatcher;
import net.minecraft.core.block.Block;
import net.minecraft.core.block.BlockLeavesBase;
import net.minecraft.core.util.helper.Side;
import net.minecraft.core.world.World;
import net.minecraft.core.world.WorldSource;
import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
import net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection;
import net.safix.esotericvaccum.client.rendering.meshing.FaceDataWriters;
import net.safix.esotericvaccum.client.rendering.meshing.IFaceWriteOrder;
import net.safix.esotericvaccum.client.util.BlockModelData;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IRenderBlockCache;
import net.safix.esotericvaccum.client.util.math.ColorBGRManager;
import net.safix.esotericvaccum.client.vertex.writer.TerrainVertexWriter;
import org.spongepowered.asm.mixin.*;

import static net.minecraft.core.block.Block.grass;

@Mixin(value = RenderBlocks.class, remap = false)
public abstract class MixinRenderBlocks {
	@Shadow private World world;
	@Shadow private boolean enableAO;
	@Shadow private RenderBlockCache cache;
	@Shadow private WorldSource blockAccess;
	@Shadow private boolean renderAllFaces;
	@Shadow @Final private static float[] SIDE_LIGHT_MULTIPLIER;
	@Shadow private int overrideBlockTexture;

	@Unique
	private static final int[] SIDE_LIGHT_INT = new int[SIDE_LIGHT_MULTIPLIER.length];

	static {
		for (int i = 0; i < SIDE_LIGHT_MULTIPLIER.length; i++) {
			SIDE_LIGHT_INT[i] = (int) (SIDE_LIGHT_MULTIPLIER[i] * 256);
		}
	}

	@Shadow
	public abstract boolean renderStandardBlock(Block block, int x, int y, int z, float r, float g, float b);

	@Shadow
	public boolean overbright;

	/**
	 * @author Safixo
	 * @reason Avoid division and get control of model meshing.
	 */
	@Overwrite
	public boolean renderStandardBlock(Block block, int x, int y, int z) {
		int color = BlockColorDispatcher.getInstance().getDispatch(block).getWorldColor(this.world, x, y, z);

		// The fast path is so unstable/experimental that for now is better to
		// not apply it to the most blocks. Most problems come down to facing issues
		// with some special blocks as pistons.
		if (block.isSolidRender() || block instanceof BlockLeavesBase) {
			this.renderBlock(block, x, y, z, ColorBGRManager.rgbToBgr(color));
		} else {
			float r = (color >> 16 & 255) * (1.0F / 255.0F);
			float g = (color >> 8  & 255) * (1.0F / 255.0F);
			float b = (color >> 0  & 255) * (1.0F / 255.0F);

			this.renderStandardBlock(block, x, y, z, r, g, b);
		}

		return true;
	}

	@Unique
	private BlockModelData blockModelData;

	@Unique
	private void renderSideFaster(Block block, int x, int y, int z, int color, int side, int topX, int topY, int topZ, int lefX, int lefY) {
		final int dirX = GraphDirection.x(side);
		final int dirY = GraphDirection.y(side);
		final int dirZ = GraphDirection.z(side);

		if (!block.shouldSideBeRendered(this.blockAccess, x + dirX, y + dirY, z + dirZ, side)) {
            return;
        }

		VertexWriterManager.getCurrentInstance().ensureCapacity(TerrainVertexWriter.STRIDE << 2);

		boolean lefT = this.cache.getOpacity(dirX + lefX, dirY + lefY, dirZ);
		boolean botT = this.cache.getOpacity(dirX - topX, dirY - topY, dirZ - topZ);
		boolean topT = this.cache.getOpacity(dirX + topX, dirY + topY, dirZ + topZ);
		boolean rigT = this.cache.getOpacity(dirX - lefX, dirY - lefY, dirZ);

		int lB = this.blockCache.getBrightnessInt(dirX + lefX, dirY + lefY, dirZ);
		int bB = this.blockCache.getBrightnessInt(dirX - topX, dirY - topY, dirZ - topZ);
		int tB = this.blockCache.getBrightnessInt(dirX + topX, dirY + topY, dirZ + topZ);
		int rB = this.blockCache.getBrightnessInt(dirX - lefX, dirY - lefY, dirZ);

		int blB;
		int tlB;

		if (lefT) {
			blB = botT ? lB : this.blockCache.getBrightnessInt(dirX + lefX - topX, dirY + lefY - topY, dirZ - topZ);
			tlB = topT ? lB : this.blockCache.getBrightnessInt(dirX + lefX + topX, dirY + lefY + topY, dirZ + topZ);
		} else {
			blB = this.blockCache.getBrightnessInt(dirX + lefX - topX, dirY + lefY - topY, dirZ - topZ);
			tlB = this.blockCache.getBrightnessInt(dirX + lefX + topX, dirY + lefY + topY, dirZ + topZ);
		}

		int brB;
		int trB;

		if (rigT) {
			brB = botT ? rB : this.blockCache.getBrightnessInt(dirX - lefX - topX, dirY - lefY - topY, dirZ - topZ);
			trB = topT ? rB : this.blockCache.getBrightnessInt(dirX - lefX + topX, dirY - lefY + topY, dirZ + topZ);
		} else {
			brB = this.blockCache.getBrightnessInt(dirX - lefX - topX, dirY - lefY - topY, dirZ - topZ);
			trB = this.blockCache.getBrightnessInt(dirX - lefX + topX, dirY - lefY + topY, dirZ + topZ);
		}

		int dirB = this.blockCache.getBrightnessInt(dirX, dirY, dirZ);

		int lightTL = (tlB + lB + tB + dirB) >>> 2;
		int lightTR = (tB + dirB + trB + rB) >>> 2;
		int lightBR = (dirB + bB + rB + brB) >>> 2;
		int lightBL = (lB + blB + dirB + bB) >>> 2;

		int faceColor = ColorBGRManager.multiplyColor(side == 1 || block != grass ? color : 0xFFFFFF, SIDE_LIGHT_INT[side]);

		int colorTopLeft = ColorBGRManager.multiplyColor(faceColor, lightTL);
		int colorBottomLeft = ColorBGRManager.multiplyColor(faceColor, lightBL);

		int colorBottomRight = ColorBGRManager.multiplyColor(faceColor, lightBR);
		int colorTopRight = ColorBGRManager.multiplyColor(faceColor, lightTR);

		int tex = block.getBlockTexture(this.blockAccess, x, y, z, Side.getSideById(side));

		this.renderFacingFace(this.blockModelData, tex, FaceDataWriters.getWriterBySide(side), colorTopLeft, colorTopRight, colorBottomLeft, colorBottomRight);

        if (tex == 3 && this.overrideBlockTexture < 0) {
			VertexWriterManager.getCurrentInstance().ensureCapacity(TerrainVertexWriter.STRIDE << 2);

			final int red   = color       & 0xFF;
			final int green = color >> 8  & 0xFF;
			final int blue  = color >> 16 & 0xFF;

			long colorTopRightTopLeft = ColorBGRManager.multiplyTwoColorsParallel(colorTopRight, colorTopLeft, red, green, blue);

			colorTopRight = (int) (colorTopRightTopLeft);
			colorTopLeft =  (int) (colorTopRightTopLeft >>> 32);

			long colorBottomRightBottomLeft = ColorBGRManager.multiplyTwoColorsParallel(colorBottomRight, colorBottomLeft, red, green, blue);

			colorBottomRight = (int) (colorBottomRightBottomLeft);
			colorBottomLeft =  (int) (colorBottomRightBottomLeft >>> 32);

			this.renderFacingFace(this.blockModelData, 70, FaceDataWriters.getWriterBySide(side), colorTopLeft, colorTopRight, colorBottomLeft, colorBottomRight);
        }
	}

	@Unique
	private float minX, minY, minZ;
	@Unique
	private float maxX, maxY, maxZ;

	@Unique
	private IRenderBlockCache blockCache;

	@Unique
	public void renderBlock(Block block, int x, int y, int z, int color) {
		this.blockCache = (IRenderBlockCache) (Object) this.cache;

		this.cache.setupCache(block, this.blockAccess, x, y, z);
		this.enableAO = true;

		this.minX = (float) block.minX;
		this.minY = (float) block.minY;
		this.minZ = (float) block.minZ;

		this.maxX = (float) block.maxX;
		this.maxY = (float) block.maxY;
		this.maxZ = (float) block.maxZ;

		this.blockModelData = new BlockModelData(
			x + this.minX, x + this.maxX,
			y + this.minY, y + this.maxY,
			z + this.minZ, z + this.maxZ
		);

		if (!this.renderAllFaces) {
			this.renderSideFaster(block, x, y, z, color, 0, 0, 0, 1, -1, 0);
			this.renderSideFaster(block, x, y, z, color, 1, 0, 0, 1, 1, 0);

			this.renderSideFaster(block, x, y, z, color, 2, -1, 0, 0, 0, 1);
			this.renderSideFaster(block, x, y, z, color, 3, 0, 1, 0, -1, 0);

			this.renderSideFaster(block, x, y, z, color, 4, 0, 0, 1, 0, 1);
			this.renderSideFaster(block, x, y, z, color, 5, 0, 0, 1, 0, -1);
		}

		this.enableAO = false;
	}

	@Unique
	private static final float INV = 1.0F / 512.0F;

	@Unique
	public void renderFacingFace(BlockModelData modelData, int uvData, IFaceWriteOrder writeOrder, int colorTopLeft, int colorTopRight, int colorBottomLeft, int colorBottomRight) {
		if (this.overrideBlockTexture >= 0) {
			uvData = this.overrideBlockTexture;
		}

		int u = (uvData & 31) << 4;

		float minU = (u + (this.minX * 16)) * INV;
		float maxU = (u + (this.maxX * 16)) * INV;

		int v = (uvData >> 5) << 4;

		float minV = (v + (this.maxY * 16)) * INV;
		float maxV = (v + (this.minY * 16)) * INV;

		writeOrder.setUV(minU, minV, maxU, maxV);

		writeOrder.vertexOne(modelData, colorTopLeft | 0xFF000000);
		writeOrder.vertexTwo(modelData, colorBottomLeft | 0xFF000000);
		writeOrder.vertexThree(modelData, colorBottomRight | 0xFF000000);
		writeOrder.vertexFour(modelData, colorTopRight | 0xFF000000);
	}
}

package net.safix.esotericvaccum.client;

import net.safix.esotericvaccum.client.util.interfaces.mixin.IFrustum;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;

public class JomlFrustum {
	private static final FrustumIntersection jomlFrustum = new FrustumIntersection();
	private static final FrustumIntersection jomlFrustumBigger = new FrustumIntersection();

	public static void passMatrix(Matrix4f matrix4f) {
		jomlFrustum.set(matrix4f);

		matrix4f.m00(matrix4f.m00() / 1.5F).m11(matrix4f.m11() / 1.5F);

		jomlFrustumBigger.set(matrix4f);
	}

	public static boolean testAab(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
		return jomlFrustum.testAab(minX, minY, minZ, maxX, maxY, maxZ);
	}

	public static boolean testAabSimpler(float posX, float posY, float posZ) {
		return ((IFrustum)jomlFrustumBigger).testAabSimpler(posX, posY, posZ);
	}

	public static void preComputeData() {
		((IFrustum)jomlFrustum).preComputeData();
	}

	public static boolean testAabFasterInt(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
		return ((IFrustum)jomlFrustum).testAabFasterInt(minX - maxX, minY - maxY, minZ - maxZ, maxX, maxY, maxZ);
	}

	public static boolean testAabFasterFloat(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
		return ((IFrustum)jomlFrustum).testAabFasterFloat(minX, minY, minZ, maxX, maxY, maxZ);
	}
}

//package net.safix.esotericvaccum.client.rendering.chunk.render;
//
//import net.minecraft.client.render.*;
//import net.minecraft.client.render.block.model.BlockModel;
//import net.minecraft.client.render.block.model.BlockModelDispatcher;
//import net.minecraft.client.render.block.model.BlockModelRenderBlocks;
//import net.minecraft.client.render.camera.ICamera;
//import net.minecraft.client.render.culling.CameraFrustum;
//import net.minecraft.core.block.Block;
//import net.minecraft.core.block.entity.TileEntity;
//import net.minecraft.core.entity.Entity;
//import net.minecraft.core.util.helper.MathHelper;
//import net.minecraft.core.util.phys.AABB;
//import net.minecraft.core.world.World;
//import net.minecraft.core.world.chunk.Chunk;
//import net.minecraft.core.world.chunk.ChunkSection;
//import net.safix.esotericvaccum.client.gl.GlVertexBuffer;
//import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
//import net.safix.esotericvaccum.client.rendering.chunk.data.FastChunkCache;
//import net.safix.esotericvaccum.client.vertex.format.DefaultVertexFormats;
//
//import java.nio.ByteBuffer;
//import java.util.List;
//
public class SectionRenderer {
//	private boolean isInitialized = false;
//	private ChunkRenderer
//
//	private GlVertexBuffer solidBuffer;
//	private GlVertexBuffer translucentBuffer;
//
//	public SectionRenderer(RenderEngine renderEngine, World world, List<TileEntity> list, int posX, int posY, int posZ, int size, int renderList) {
//		this.worldObj = world;
//		this.tileEntities = list;
//		this.sizeWidth = this.sizeHeight = this.sizeDepth = size;
//		this.rendererRadius = MathHelper.sqrt_float((float)(this.sizeWidth * this.sizeWidth + this.sizeHeight * this.sizeHeight + this.sizeDepth * this.sizeDepth)) / 2.0F;
//		this.glRenderList = renderList;
//		this.setPosition(posX, posY, posZ);
//		this.needsUpdate = false;
//	}
//
//	public void setPosition(int x, int y, int z) {
//		if (x != this.posX || y != this.posY || z != this.posZ) {
//			this.setDontDraw();
//			this.posX = x;
//			this.posY = y;
//			this.posZ = z;
//			float f = 6.0F;
//			this.rendererBoundingBox = AABB.getBoundingBox(x - f, y - f, z - f, x + 16 + f, y + 16 + f, z + 16 + f);
//			this.markDirty();
//		}
//	}
//
//
//	public void setDontDraw() {
//		for(int i = 0; i < 2; ++i) {
//			this.skipRenderPass[i] = true;
//		}
//
//		this.isInFrustum = false;
//		this.isInitialized = false;
//	}
//
//
//
//	public void reset() {
//		this.setDontDraw();
//		this.worldObj = null;
//	}
//	public GlVertexBuffer getBuffer(int renderPass) {
//		return renderPass == 0 ? this.solidBuffer : this.translucentBuffer;
//	}
//
//
//	public void updateRenderer() {
//		if (!this.needsUpdate) {
//			return;
//		}
//
//		for (int i = 0; i < 2; ++i) {
//			this.skipRenderPass[i] = true;
//		}
//
//		Chunk.isLit = false;
//
//		int minX = this.posX;
//		int minY = this.posY;
//		int minZ = this.posZ;
//
//		int maxX = minX + 16;
//		int maxY = minY + 16;
//		int maxZ = minZ + 16;
//
//		Chunk chunk = this.worldObj.getChunkFromBlockCoords(minX, minZ);
//		ChunkSection section = chunk.getSection(minY >> 4);
//
//		if (section.blocks == null) {
//			return;
//		}
//
//		FastChunkCache chunkCache = new FastChunkCache(this.worldObj, minX - 1, minZ - 1, maxX + 1, maxZ + 1);
//
//		RenderBlocks renderBlocks = new RenderBlocks(this.worldObj, chunkCache);
//		BlockModelRenderBlocks.setRenderBlocks(renderBlocks);
//
//		final Tessellator tessellator = Tessellator.instance;
//		final short[] blocks = section.blocks;
//
//		for (int renderPass = 0; renderPass < 2; ++renderPass) {
//			boolean needsMoreRenderPasses = false;
//			boolean hasRenderedBlock = false;
//			boolean hasStartedDrawing = false;
//
//			for (int y = minY; y < maxY; ++y) {
//				for (int z = minZ; z < maxZ; ++z) {
//					for (int x = minX; x < maxX; ++x) {
//						int blockId = blocks[makeBlockIndex(x & 15, y & 15, z & 15)];
//
//						if (blockId <= 0) {
//							continue;
//						}
//
//						if (!hasStartedDrawing) {
//							VertexWriterManager.startDrawing();
//							VertexWriterManager.setVertexFormat(DefaultVertexFormats.TERRAIN_FORMAT);
//							VertexWriterManager.setPos(-this.posX, -this.posY, -this.posZ);
//
//							hasStartedDrawing = true;
//						}
//
//						if (renderPass == 0 && Block.isEntityTile[blockId]) {
//							TileEntity tileentity = chunkCache.getBlockTileEntity(x, y, z);
//							if (TileEntityRenderDispatcher.instance.hasRenderer(tileentity)) {
//								this.specialTileEntities.add(tileentity);
//							}
//						}
//
//						Block block = Block.blocksList[blockId];
//						int blockRenderPass = block.getRenderBlockPass();
//
//						if (blockRenderPass != renderPass) {
//							needsMoreRenderPasses = true;
//						} else {
//							BlockModel model = BlockModelDispatcher.getInstance().getDispatch(block);
//							hasRenderedBlock |= model.render(block, x, y, z);
//							if (block.hasOverbright) {
//								renderBlocks.overbright = true;
//								hasRenderedBlock |= model.render(block, x, y, z);
//								renderBlocks.overbright = false;
//							}
//						}
//
//					}
//				}
//			}
//
//			if (hasStartedDrawing) {
//				int vertices = VertexWriterManager.getVertices();
//				ByteBuffer vertexData = VertexWriterManager.getVertexData();
//
//				this.feedupBuffer(vertexData, renderPass, vertices);
//
//				VertexWriterManager.stopDrawing();
//
//			} else {
//				hasRenderedBlock = false;
//			}
//
//			if (hasRenderedBlock) {
//				this.skipRenderPass[renderPass] = false;
//			}
//
//			if (!needsMoreRenderPasses) {
//				break;
//			}
//		}
//
//
//		this.isChunkLit = Chunk.isLit;
//		this.isInitialized = true;
//	}
//
//	private static int makeBlockIndex(int x, int y, int z) {
//		return (y << 8) + (z << 4) + x;
//	}
//
//	private void feedupBuffer(ByteBuffer vertexData, int renderPass, int vertices) {
//		if (renderPass == 0) {
//			if (this.solidBuffer == null) this.solidBuffer = new GlVertexBuffer(DefaultVertexFormats.TERRAIN_FORMAT);
//			this.solidBuffer.upload(vertexData, vertices);
//		} else {
//			if (this.translucentBuffer == null) this.translucentBuffer = new GlVertexBuffer(DefaultVertexFormats.TERRAIN_FORMAT);
//			this.translucentBuffer.upload(vertexData, vertices);
//		}
//	}
//
//	public float distanceToEntitySquared(Entity entity) {
//		float dx = (float) (entity.x - this.posXPlus);
//		float dy = (float) (entity.y - this.posYPlus);
//		float dz = (float) (entity.z - this.posZPlus);
//
//		return (dx * dx) + (dy * dy) + (dz * dz);
//	}
//
//	public float distanceToCameraSquared(ICamera camera) {
//		float dx = (float) (camera.getX(1.0F) - this.posXPlus);
//		float dy = (float) (camera.getY(1.0F) - this.posYPlus);
//		float dz = (float) (camera.getZ(1.0F) - this.posZPlus);
//
//		return (dx * dx) + (dy * dy) + (dz * dz);
//	}
//
//	public void updateInFrustum(CameraFrustum frustum, float partialTick) {
//		this.isInFrustum = frustum.isVisible(this.rendererBoundingBox, partialTick);
//	}
//
//	public boolean skipAllRenderPasses() {
//		if (!this.isInitialized) {
//			return false;
//		} else {
//			return this.skipRenderPass[0] && this.skipRenderPass[1];
//		}
//	}
//
//	public void markDirty() {
//		this.needsUpdate = true;
//	}
//
}

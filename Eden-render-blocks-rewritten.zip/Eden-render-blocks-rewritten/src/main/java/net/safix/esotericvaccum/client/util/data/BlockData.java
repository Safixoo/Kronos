package net.safix.esotericvaccum.client.util.data;

import net.minecraft.client.render.block.model.BlockModel;
import net.minecraft.core.block.Block;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.PixelFormat;

public class BlockData {
	public BlockModel model;
	public Block block;
	public int x, y, z;

	public BlockData(Block block, int x, int y, int z, BlockModel model) {
		this.block = block;
		this.model = model;
		this.x = x;
		this.y = y;
		this.z = z;
	}
}

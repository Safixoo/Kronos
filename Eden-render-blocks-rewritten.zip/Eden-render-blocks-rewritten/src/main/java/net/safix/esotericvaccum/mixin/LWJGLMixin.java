package net.safix.esotericvaccum.mixin;

import org.lwjgl.LWJGLUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value = LWJGLUtil.class, remap = false)
public class LWJGLMixin {
	@Shadow
	@Final
	@Mutable
	public static boolean CHECKS;

	static {
		CHECKS = false;
	}
}

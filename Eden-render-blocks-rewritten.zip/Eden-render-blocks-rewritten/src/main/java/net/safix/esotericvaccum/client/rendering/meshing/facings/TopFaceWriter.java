package net.safix.esotericvaccum.client.rendering.meshing.facings;

import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
import net.safix.esotericvaccum.client.rendering.meshing.IFaceWriteOrder;
import net.safix.esotericvaccum.client.util.BlockModelData;

public class TopFaceWriter implements IFaceWriteOrder {
	private float minU, minV, maxU, maxV;

	@Override
	public void setUV(float minU, float minV, float maxU, float maxV) {
		this.minU = minU;
		this.minV = minV;
		this.maxU = maxU;
		this.maxV = maxV;
	}

	@Override
	public void vertexOne(BlockModelData model, int color) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		man.setPos(model.maxX, model.maxY, model.maxZ);
		man.setUV(minU, maxV);
		man.setColor(color);
		man.addVertexUnsafe();
	}

	@Override
	public void vertexTwo(BlockModelData model, int color) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		man.setPos(model.maxX, model.maxY, model.minZ);
		man.setUV(minU, minV);
		man.setColor(color);
		man.addVertexUnsafe();
	}

	@Override
	public void vertexThree(BlockModelData model, int color) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		man.setPos(model.minX, model.maxY, model.minZ);
		man.setUV(maxU, minV);
		man.setColor(color);
		man.addVertexUnsafe();
	}

	@Override
	public void vertexFour(BlockModelData model, int color) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		man.setPos(model.minX, model.maxY, model.maxZ);
		man.setUV(maxU, maxV);
		man.setColor(color);
		man.addVertexUnsafe();
	}
}

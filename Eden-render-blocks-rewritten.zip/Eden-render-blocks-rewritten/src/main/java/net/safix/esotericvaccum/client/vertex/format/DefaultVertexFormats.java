package net.safix.esotericvaccum.client.vertex.format;

import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.Immutable;
import net.safix.esotericvaccum.client.vertex.operations.VertexOperations;
import net.safix.esotericvaccum.client.vertex.writer.TerrainVertexWriter;

import static net.safix.esotericvaccum.client.vertex.format.VertexProperty.*;

public class DefaultVertexFormats {
	public static final VertexProperty NORMAL = new VertexProperty(3, Type.BYTE, VertexOperations.NORMAL);
	public static final VertexProperty POSITION = new VertexProperty(3, Type.FLOAT, VertexOperations.POSITION);
	public static final VertexProperty TEXTURE = new VertexProperty(2, Type.FLOAT, VertexOperations.TEXTURE);
	public static final VertexProperty COLOR = new VertexProperty(4, Type.UBYTE, VertexOperations.COLOR);

	public static final VertexFormat TERRAIN_FORMAT = new VertexFormat(
		new ImmutableList.Builder<VertexProperty>()
			.add(TEXTURE)
			.add(COLOR)
			.add(POSITION)
			.build(),
			TerrainVertexWriter.writer
	);
	public static final VertexFormat ENTITY_FORMAT = new VertexFormat(
		new ImmutableList.Builder<VertexProperty>()
			.add(POSITION)
			.add(TEXTURE)
			.add(NORMAL)
			.build(),
			null
	);
}

package net.safix.esotericvaccum.mixin.data;

import net.minecraft.core.world.data.ChunkUnsignedByteArray;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Random;

@Mixin(value = ChunkUnsignedByteArray.class, remap = false)
public class ChunkByteArrayMixin {
	@Shadow @Final public byte[] data;

	/**
	 * @author Safixo
	 * @reason Dangerous but it avoids "unnecessary" indirection.
	 */
	@Overwrite
	public Integer get(int x, int y, int z) {
		int index = (y << 8) | (z << 4) | x;
		return Byte.toUnsignedInt(this.data[index]);
	}
}

package net.safix.esotericvaccum.client.gl;

import net.safix.esotericvaccum.client.vertex.format.DefaultVertexFormats;
import net.safix.esotericvaccum.client.vertex.format.VertexFormat;
import org.lwjgl.opengl.*;

import java.nio.ByteBuffer;

public class GlVertexBuffer {
	private final VertexFormat vertexFormat;

	private int vbo;
	private int vao;
	private int vertexCount;
	private boolean buffersReady = true;
	private boolean hasData = false;
	private boolean vaoSetup = false;

	public GlVertexBuffer(VertexFormat vertexFormat) {
		this.vbo = GL15.glGenBuffers();
		this.vao = GL30.glGenVertexArrays();
		this.vertexFormat = vertexFormat;
	}

	public void draw() {
		GL11.glDrawArrays(GL11.GL_QUADS, 0, this.vertexCount);
	}

	public void upload(ByteBuffer buffer, int vertexCount) {
		if (!this.buffersReady) this.prepareBuffers();
		if (!this.vaoSetup) this.prepareVAO();
		this.vertexCount = vertexCount;
		buffer.position(0);
		this.uploadBuffer(buffer);
	}

	private void uploadBuffer(ByteBuffer buffer) {
		this.bind();
		GL45.glNamedBufferData(this.vbo, buffer, GL15.GL_STREAM_DRAW);
		this.unbind();
		this.hasData = true;
	}

	public void clear() {
		if (this.vbo >= 0) GL15.glDeleteBuffers(this.vbo);
		if (this.vao >= 0) GL30.glDeleteVertexArrays(this.vao);
		this.hasData = false;
		this.buffersReady = false;
	}

	public void prepareBuffers() {
		this.vbo = GL15.glGenBuffers();
		this.vao = GL30.glGenVertexArrays();
		this.buffersReady = true;
	}

	public boolean buffersPrepared() {
		return this.buffersReady;
	}

	public boolean hasData() {
		return this.hasData;
	}

	// populates vao state data
	private void prepareVAO() {
		boolean terrainFormat = vertexFormat == DefaultVertexFormats.TERRAIN_FORMAT;

		this.bindVAO();
		this.bind();
		if (terrainFormat) GL11.glInterleavedArrays(GL11.GL_T2F_C4UB_V3F, 24, 0L);
		else vertexFormat.setupBufferState();
		this.unbind();
		this.unbindVAO();
		if (!terrainFormat) vertexFormat.cleanupBufferState();

		this.vaoSetup = true;
	}

	public void renderVAO() {
		this.bindVAO();
		this.draw();
		this.unbindVAO();
	}

	public void render() {
		this.bind();
		vertexFormat.setupBufferState();
		this.draw();
		vertexFormat.cleanupBufferState();
		this.unbind();
	}

	public void bind() {
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.vbo);
	}

	public void unbind() {
		GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
	}

	public void bindVAO() {
		GL30.glBindVertexArray(this.vao);
	}

	public void bindVAOAdvanced(long caps) {

	}

	public void unbindVAO() {
		GL30.glBindVertexArray(0);
	}
}


package net.safix.esotericvaccum.mixin;

import net.minecraft.client.render.OpenGLHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value = OpenGLHelper.class, remap = false)
public class MixinOpenGLHelper {
	/**
	 * @author Safixo
	 * @reason Disable GL error checking, TODO: leave it under a option.
	 */
	@Overwrite
	public static void checkError(String info) {}
}

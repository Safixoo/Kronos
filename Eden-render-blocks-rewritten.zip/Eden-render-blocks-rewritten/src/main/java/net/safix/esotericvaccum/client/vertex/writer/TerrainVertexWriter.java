package net.safix.esotericvaccum.client.vertex.writer;

import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
import net.safix.esotericvaccum.client.util.interfaces.IVertexWriter;

import java.nio.ByteBuffer;

import static net.safix.esotericvaccum.client.rendering.VertexWriterManager.*;

// In difference with modern Minecraft, beta seems to not use a lighting
// attribute (???), it simply uses lighting baked in color attribute.
// Which makes the difference in whereas not using lighting baked in a
// texture it doesn't produces as smoothly chunk transitions as it has
// to redo the vertex data to change lighting, which makes the rare transitions
// at the morning/afternoon of the game.
public class TerrainVertexWriter implements IVertexWriter {
	public static int STRIDE = 24;
	public static IVertexWriter writer = new TerrainVertexWriter();

	@Override
	public void writeVertex(ByteBuffer buffer, int offset) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		buffer.putFloat(offset + 0, man.u);
		buffer.putFloat(offset + 4, man.v);

		buffer.putInt(offset + 8, man.color);

		buffer.putFloat(offset + 12, man.x + man.transX);
		buffer.putFloat(offset + 16, man.y + man.transY);
		buffer.putFloat(offset + 20, man.z + man.transZ);
	}

	@Override
	public int getStride() {
		return STRIDE;
	}
}

package net.safix.esotericvaccum.mixin.data;

import net.minecraft.core.world.chunk.Chunk;
import net.minecraft.core.world.chunk.ChunkSection;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value = Chunk.class, remap = false)
public abstract class MixinChunk {
	@Shadow
	public static boolean isLit;

	@Shadow
	@Final
	private ChunkSection[] sections;

	/**
	 * @author Safixo
	 * @reason Faster
	 */
	@Overwrite
	public int getBlockID(int x, int y, int z) {
		return this.sections[y >> 4].getBlock(x, y & 15, z);
	}

	/**
	 * @author Safixo
	 * @reason Faster
	 */
	@Overwrite
	public ChunkSection getSection(int index) {
		return this.sections[index];
	}

	/**
	 * @author Safixo
	 * @reason Faster
	 */
	@Overwrite
	public int getRawBrightness(int x, int y, int z, int skySubtract) {
		int lightValue = this.sections[y >> 4].getRawBrightness(x, y & 15, z, skySubtract);

		if (lightValue > 0) isLit = true;


		return lightValue;
	}

	/**
	 * @author Safixo
	 * @reason Avoid excessive bounds-checking and use Bitwise-Math.
	 */
	@Overwrite
	public int getBlockMetadata(int x, int y, int z) {
		return this.getSection(y >> 4).getData(x, y & 15, z);
	}
}

package net.safix.esotericvaccum.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.MinecraftApplet;
import net.minecraft.client.render.window.GameWindowApplet;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.PixelFormat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.awt.*;

@Mixin(value = GameWindowApplet.class, remap = false)
public class GameWindowAppletMixin {
	@Shadow
	private Minecraft mc;

	@Shadow
	private Canvas canvas;

	@Shadow
	private MinecraftApplet applet;

	/**
	 * @author
	 * @reason
	 */
	@Overwrite
	public void init(Minecraft minecraft) throws LWJGLException {
		try {
			Display.create(new PixelFormat(0, 0, 0));
			Display.update();
		} catch (Exception var6) {
			var6.printStackTrace();

			try {
				Thread.sleep(1000L);
			} catch (Exception ignored) {
			}

			Display.create();
		}

	}
}

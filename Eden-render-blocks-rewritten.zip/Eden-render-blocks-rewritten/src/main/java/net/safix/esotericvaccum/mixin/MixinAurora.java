package net.safix.esotericvaccum.mixin;

import net.minecraft.core.world.AuroraProvider;
import net.minecraft.core.world.noise.ImprovedNoise;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IAurora;
import org.spongepowered.asm.mixin.*;

@Mixin(value = AuroraProvider.class, remap = false)
public class MixinAurora {
	@Shadow @Final private ImprovedNoise noise;

	/**
	 * @author Safixo
	 * @reason Faster?
	 */
	@Overwrite
	public float getAuroraPresence(float x, float z, long worldTime, float celestialAngle) {
		if ((celestialAngle < 0.25F) || (celestialAngle > 0.75F)) {
			return 0.0F;
		}

		IAurora auroraNoiser = (IAurora) this.noise;

		float sample = auroraNoiser.getValue(x * 0.001F, worldTime * 0.0002F, z * 0.001F);
		sample += auroraNoiser.getValue(x * 0.03333333F, worldTime * 0.2F, z * 0.03333333F) * 0.05F;

		if (sample >= -0.03F && sample <= 0.03F) {
			sample *= 33.33333F;
			sample = -Math.abs(sample) + 1.0F;

			celestialAngle = (celestialAngle - 0.25F) * 4.0F - 1.0F;
			celestialAngle = -Math.abs(celestialAngle) + 1.0F;

			return sample * celestialAngle;
		}

        return 0.0F;
    }
}

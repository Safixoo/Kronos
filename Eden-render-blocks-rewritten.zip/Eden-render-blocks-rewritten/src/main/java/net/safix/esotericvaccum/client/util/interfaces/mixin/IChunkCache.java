package net.safix.esotericvaccum.client.util.interfaces.mixin;

import net.minecraft.core.world.chunk.Chunk;

public interface IChunkCache {
	Chunk getChunk(int x, int y, int z);
	boolean getSolidUnsafe(int x, int y, int z);
}

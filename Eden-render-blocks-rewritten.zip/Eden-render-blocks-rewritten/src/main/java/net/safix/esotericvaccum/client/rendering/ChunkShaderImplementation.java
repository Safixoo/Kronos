package net.safix.esotericvaccum.client.rendering;

import net.minecraft.client.render.shader.Shader;
import net.safix.esotericvaccum.client.gl.GlProgram;
import net.safix.esotericvaccum.client.gl.GlShader;

public class ChunkShaderImplementation {
	private static ChunkShaderImplementation INSTANCE;

	private final GlProgram program;
	private final GlShader vertexShader;
	private final GlShader fragmentShader;

	public static ChunkShaderImplementation getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new ChunkShaderImplementation();
		}

		return INSTANCE;
	}

	public ChunkShaderImplementation() {
		this.program = new GlProgram();
		this.vertexShader = new GlShader(GlShader.VERTEX_SHADER);
		this.fragmentShader = new GlShader(GlShader.FRAGMENT_SHADER);

		this.program.attachShader(this.vertexShader.getId());
		this.program.attachShader(this.fragmentShader.getId());
	}

	public void bindProgram() {
		this.program.bindProgram();
	}

	public void unbindProgram() {
		this.program.unbindProgram();
	}
}

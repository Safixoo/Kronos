package net.safix.esotericvaccum.client.util.interfaces.mixin;

public interface IFrustum {
	boolean testAabSimpler(float minX, float minY, float minZ);

	boolean testAabFasterInt(int minX, int minY, int minZ, int maxX, int maxY, int maxZ);

	boolean testAabFasterFloat(float minX, float minY, float minZ, float maxX, float maxY, float maxZ);

	void preComputeData();
}

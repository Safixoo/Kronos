package net.safix.esotericvaccum.client.rendering.cull.chunk;


import net.safix.esotericvaccum.client.rendering.cull.direction.Direction;

public class ChunkGraphColumn {
    private final ChunkGraphNode[] renders = new ChunkGraphNode[16];

    private final ChunkGraphColumn[] adjacent = new ChunkGraphColumn[6];

    private final int x, z;

    private static final Direction[] CORNER_DIRECTIONS = new Direction[6];

    static {
        // 2 -> 5
        CORNER_DIRECTIONS[Direction.NORTH.ordinal()] = Direction.EAST;
        // 3 -> 4
        CORNER_DIRECTIONS[Direction.SOUTH.ordinal()] = Direction.WEST;
        // 4 -> 2
        CORNER_DIRECTIONS[Direction.WEST.ordinal()] = Direction.NORTH;
        // 5 -> 3
        CORNER_DIRECTIONS[Direction.EAST.ordinal()] = Direction.SOUTH;
    }

    public ChunkGraphColumn(int x, int z) {
        this.x = x;
        this.z = z;

        this.setAdjacentColumn(1, this);
        this.setAdjacentColumn(0, this);
    }

    public void setAdjacentColumn(Direction dir, ChunkGraphColumn column) {
        this.adjacent[dir.ordinal()] = column;
    }

    public void setAdjacentColumn(int dir, ChunkGraphColumn column) {
        this.adjacent[dir] = column;
    }

    public ChunkGraphColumn getAdjacentColumn(int dir) {
        return this.adjacent[dir];
    }

    public void setRender(int y, ChunkGraphNode render) {
        this.renders[y] = render;
    }

    public ChunkGraphNode getRender(int y) {
        if (y < 0 || y >= this.renders.length) {
            return null;
        }
        return this.renders[y];
    }

    public int getX() {
        return this.x;
    }

    public int getZ() {
        return this.z;
    }
}

package net.safix.esotericvaccum.client.rendering.meshing;



import net.safix.esotericvaccum.client.rendering.meshing.facings.*;

import static net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection.*;

public class FaceDataWriters {
	private static final IFaceWriteOrder[] FACING_WRITERS = new IFaceWriteOrder[6];

	static {
		FACING_WRITERS[DOWN] = new BottomFaceWriter();
		FACING_WRITERS[UP] = new TopFaceWriter();

		FACING_WRITERS[NORTH] = new NorthFaceWriter();
		FACING_WRITERS[SOUTH] = new SouthFaceWriter();

		FACING_WRITERS[EAST] = new EastFaceWriter();
		FACING_WRITERS[WEST] = new WestFaceWriter();
	}

	public static IFaceWriteOrder getWriterBySide(int side) {
		return FACING_WRITERS[side];
	}
}

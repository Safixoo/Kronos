package net.safix.esotericvaccum.client.gl;

import org.lwjgl.opengl.GL30;

public class GlVertexArrayObject {
	private final int id;

	public GlVertexArrayObject() {
		this.id = GL30.glGenVertexArrays();
	}

	public void bind() {
		GL30.glBindVertexArray(this.id);
	}

	public void unbind() {
		GL30.glBindVertexArray(0);
	}

	public void close() {
		GL30.glDeleteVertexArrays(this.id);
	}

	public int getId() {
		return id;
	}
}

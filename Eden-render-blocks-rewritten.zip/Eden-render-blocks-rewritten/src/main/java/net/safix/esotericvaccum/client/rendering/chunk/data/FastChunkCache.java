package net.safix.esotericvaccum.client.rendering.chunk.data;

import it.unimi.dsi.fastutil.longs.Long2ReferenceMap;
import it.unimi.dsi.fastutil.longs.Long2ReferenceOpenHashMap;
import net.minecraft.core.block.Block;
import net.minecraft.core.block.entity.TileEntity;
import net.minecraft.core.block.material.Material;
import net.minecraft.core.world.World;
import net.minecraft.core.world.WorldSource;
import net.minecraft.core.world.chunk.Chunk;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IBlock;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IChunkCache;
import org.spongepowered.asm.mixin.Unique;

public class FastChunkCache implements WorldSource, IChunkCache {
	private final int chunkX;
	private final int chunkZ;
	private final Chunk[][] chunkArray;
	private final World worldObj;

	// cache not null chunks to avoid pulling from the worldObj the chunks each time a section is meshed
	private static final Long2ReferenceMap<Chunk> chunkPosToChunk = new Long2ReferenceOpenHashMap<>();

	public FastChunkCache(World world, int minX, int minZ, int maxX, int maxZ) {
		this.worldObj = world;

		this.chunkX = minX >> 4;
		this.chunkZ = minZ >> 4;

		int maxChunkX = maxX >> 4;
		int maxChunkZ = maxZ >> 4;

		this.chunkArray = new Chunk[maxChunkX - this.chunkX + 1][maxChunkZ - this.chunkZ + 1];

		for(int x = this.chunkX; x <= maxChunkX; ++x) {
			for(int z = this.chunkZ; z <= maxChunkZ; ++z) {
				this.chunkArray[x - this.chunkX][z - this.chunkZ] = getChunkFromCache(world, x, z);
			}
		}
	}

	private static Chunk getChunkFromCache(World world, int x, int z) {
		long pos = (long) x << 32 | z;
		Chunk chunk;

		if (!chunkPosToChunk.containsKey(pos)) {
			chunk = world.getChunkFromChunkCoords(x, z);
			chunkPosToChunk.put(pos, chunk);
		} else {
			chunk = chunkPosToChunk.get(pos);
		}

		return chunk;
	}

	@Unique
	private boolean getIsLitInteriorSurface(int x, int y, int z) {
		int id = this.getBlockId(x, y, z);
		return id != 0 && ((IBlock) Block.blocksList[id]).getLitInterior();
	}

	public boolean getBlockLitInteriorSurface(int i, int j, int k) {
		return j < 0 || j >= 256 || getIsLitInteriorSurface(i, j, k);
	}

	@Override
	public int getBlockId(int x, int y, int z) {
		if (y < 0 || y >= 255) {
			return 0;
		}

		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;

		// ((xc - (xc & 2))) < 0 && (zc - (zc & 2) < 0)
		if ((xc - (xc & 2)) < 0 && (zc - (zc & 2)) < 0) {
			Chunk chunk = this.chunkArray[xc][zc];
			return chunk == null ? 0 : chunk.getSection(y >> 4).getBlock(x & 15, y & 15, z & 15);
		}

		return 0;
	}

	@Override
	public Block getBlock(int x, int y, int z) {
		return Block.getBlock(this.getBlockId(x, y, z));
	}

	@Override
	public TileEntity getBlockTileEntity(int x, int y, int z) {
		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;
		return this.chunkArray[xc][zc].getTileEntity(x & 15, y, z & 15);
	}
	@Override
	public float getBrightness(int x, int y, int z, int blockLightValue) {
		int i1 = this.getLightValue(x, y, z);

		return this.worldObj.worldType.getBrightnessRamp()[ Math.max(i1, blockLightValue) ];
	}

	public int getLightValue(int i, int j, int k) {
		if (j < 0 || j >= 255) {
			return 15;
		}

		Block block = Block.blocksList[getBlockId(i, j, k)];

		boolean isNull = block == null;

		if (!isNull && block.isSolidRender()) {
			return 0;
		}

		if (isNull || ((IBlock)block).getLitInterior()) {
			int k1 = this.getRawBrightness(i, j + 1, k);
			int l1 = this.getRawBrightness(i + 1, j, k);
			int j2 = this.getRawBrightness(i - 1, j, k);
			int k2 = this.getRawBrightness(i, j, k + 1);
			int l2 = this.getRawBrightness(i, j, k - 1);

			if (k1 < l1) k1 = l1;
			if (k1 < j2) k1 = j2;
			if (k1 < k2) k1 = k2;
			if (k1 < l2) k1 = l2;

			return k1;
		}

		int xc = (i >> 4) - this.chunkX;
		int zc = (k >> 4) - this.chunkZ;
		return this.chunkArray[xc][zc].getRawBrightness(i & 15, j, k & 15, this.worldObj.skyDarken);
	}


	public int getRawBrightness(int i, int j, int k) {
		int xc = (i >> 4) - this.chunkX;
		int zc = (k >> 4) - this.chunkZ;
		return this.chunkArray[xc][zc].getSection(j >> 4).getRawBrightness(i & 15, j & 15, k & 15, this.worldObj.skyDarken);
		//return this.chunkArray[xc][zc].getRawBrightness(i & 15, j, k & 15, this.worldObj.skyDarken);
	}

	@Override
	public float getLightBrightness(int x, int y, int z) {
		return this.worldObj.worldType.getBrightnessRamp()[this.getLightValue(x, y, z)];
	}

	@Override
	public int getBlockMetadata(int x, int y, int z) {
		if (y < 0 || y >= 256) {
			return 0;
		}

		int chunkX = (x >> 4) - this.chunkX;
		int chunkZ = (z >> 4) - this.chunkZ;
		return this.chunkArray[chunkX][chunkZ].getBlockMetadata(x & 15, y, z & 15);
	}

	@Override
	public Material getBlockMaterial(int x, int y, int z) {
		int blockId = this.getBlockId(x, y, z);
		return blockId == 0 ? Material.air : Block.blocksList[blockId].blockMaterial;
	}

	@Override
	public boolean isBlockOpaqueCube(int x, int y, int z) {
		return Block.solid[this.getBlockId(x, y, z)];
	}

	@Override
	public boolean isBlockNormalCube(int x, int y, int z) {
		int blockId = this.getBlockId(x, y, z);

		if (blockId == 0) {
			return false;
		}

		Block block = Block.blocksList[blockId];

		return block.blockMaterial.blocksMotion() && block.renderAsNormalBlock();
	}

	@Override
	public Chunk getChunk(int x, int y, int z) {
		if (y < 0 || y >= 256) {
			return null;
		}

		int chunkX = (x >> 4) - this.chunkX;
		int chunkZ = (z >> 4) - this.chunkZ;

		return this.chunkArray[chunkX][chunkZ];
	}

	@Override
	public boolean getSolidUnsafe(int x, int y, int z) {
		if (y < 0 || y >= 255) {
			return false;
		}

		int l = (x >> 4) - this.chunkX;
		int i1 = (z >> 4) - this.chunkZ;

		return Block.solid[this.chunkArray[l][i1].getBlockID(x & 15, y, z & 15)];
	}
}

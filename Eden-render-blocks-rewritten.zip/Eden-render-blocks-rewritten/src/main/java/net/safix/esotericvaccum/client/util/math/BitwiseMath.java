package net.safix.esotericvaccum.client.util.math;

/**
 * Some of the methods have been taken from Upstream Sodium,
 * and others as the fast integer absolute value from
 * <a href="https://graphics.stanford.edu/~seander/bithacks.html">...</a>.
 * And some of the rest simply have been ideas from me :P.
 */

public class BitwiseMath {
	public static int lessThan(int a, int b) {
		return (a - b) >>> 31;
	}

	public static int greaterThan(int a, int b) {
		return (b - a) >>> 31;
	}

	public static int abs(int num) {
		int mask = num >> 31;

		return (num + mask) ^ mask;
	}

	public static int min(int num1, int num2) {
		int diff = num2 - num1;
		return num1 - (diff >> 31 & diff);
	}

	public static int max(int num1, int num2) {
		int diff = num1 - num2;
		return num1 - (diff >> 31 & diff);
	}

	public static int smallestEncompassingPowerOfTwo(int value) {
		value--;
		value |= value >> 1;
		value |= value >> 2;
		value |= value >> 4;
		value |= value >> 8;
		value |= value >> 16;

		return value + 1;
	}
}

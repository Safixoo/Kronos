package net.safix.esotericvaccum.client.util.interfaces;

import net.safix.esotericvaccum.client.rendering.VertexWriterManager;

import java.nio.Buffer;
import java.nio.ByteBuffer;

public interface IVertexWriter {
	void writeVertex(ByteBuffer buffer, int vertexIndex);
	int getStride();
}

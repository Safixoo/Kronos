package net.safix.esotericvaccum.mixin.data;

import net.minecraft.core.block.Block;
import net.minecraft.core.world.World;
import net.minecraft.core.world.chunk.Chunk;
import net.minecraft.core.world.chunk.ChunkCache;
import net.safix.esotericvaccum.client.BlockCacheData;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IBlock;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IChunkCache;
import net.safix.esotericvaccum.client.util.math.BitwiseMath;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.minecraft.core.world.chunk.ChunkSection.makeBlockIndex;

@Mixin(value = ChunkCache.class, remap = false)
public class MixinChunkCache implements IChunkCache {
	@Mutable @Shadow @Final private World worldObj;
	@Mutable @Shadow @Final private int chunkZ;
	@Mutable @Shadow @Final private int chunkX;
	@Mutable @Shadow @Final private Chunk[][] chunkArray;

	@Mutable
	@Unique @Final
	private float[] brightnessRamp;

	@Inject(method = "<init>", at = @At("TAIL"))
	private void initData(World world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ, CallbackInfo ci) {
		this.brightnessRamp = world.worldType.getBrightnessRamp();
	}

	/**
	 * @author Safixo
	 * @reason Implement faster check
	 */
	@Overwrite
	public boolean isBlockOpaqueCube(int x, int y, int z) {
		return Block.solid[this.getBlockId(x, y, z)];
	}

	/**
	 * @author Safixo
	 * @reason Optimize metadata pulling
	 */
	@Overwrite
	public int getBlockMetadata(int x, int y, int z) {
		if (y < 0 || y >= 256) {
			return 0;
		}

		int chunkX = (x >> 4) - this.chunkX;
		int chunkZ = (z >> 4) - this.chunkZ;
		return this.chunkArray[chunkX][chunkZ].getBlockMetadata(x & 15, y, z & 15);
	}

	/**
	 * @author Safixo
	 * @reason Instead of using the worldObj, use directly our chunk cache for fetching block data.
	 */
	@Overwrite
	public boolean getBlockLitInteriorSurface(int x, int y, int z) {
		return y < 0 || y >= 256 || this.getIsLitInteriorSurface(x, y, z);
	}

	@Unique
	private boolean getIsLitInteriorSurface(int x, int y, int z) {
		return BlockCacheData.hasLightInterior[this.getBlockId(x, y, z)];
	}

	@Unique
	private int getBlockId(int x, int y, int z) {
		if (y < 0 || y >= 256) {
			return 0;
		}

		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;

		Chunk chunk = this.chunkArray[xc][zc];
		return chunk == null ? 0 : chunk.getSection(y >> 4).getBlock(x & 15, y & 15, z & 15);
	}

	@Unique
	private int getBlockIdUnsafe(int x, int y, int z) {
		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;

		Chunk chunk = this.chunkArray[xc][zc];
		return chunk.getSection(y >> 4).blocks[makeBlockIndex(x & 15, y & 15, z & 15)];
	}

	@Unique
	public boolean getSolidUnsafe(int x, int y, int z) {
		return Block.solid[this.getBlockIdUnsafe(x, y, z)];
	}

	/**
	 * @author Safixo
	 * @reason Faster brightness pulling
	 */
	@Overwrite
	public float getBrightness(int x, int y, int z, int blockLightValue) {
		int brightness = this.getLightValue(x, y, z);

		return this.brightnessRamp[BitwiseMath.max(brightness, blockLightValue)];
	}

	@Unique
	public int getLightValue(int x, int y, int z) {
		if (y < 0 || y >= 255) {
			return 15;
		}

		int blockId = this.getBlockId(x, y, z);

		if (Block.solid[blockId]) {
			return 0;
		}

		if (BlockCacheData.hasLightInterior[blockId]) {
			int u = this.getRawBrightness(x, y + 1, z);
			int e = this.getRawBrightnessMax(x + 1, y, z, u);
			int w = this.getRawBrightnessMax(x - 1, y, z, e);
			int n = this.getRawBrightnessMax(x, y, z + 1, w);

            return this.getRawBrightnessMax(x, y, z - 1, n);
		}

		return this.getRawBrightness(x, y, z);
	}

	@Unique
	public int getRawBrightness(int x, int y, int z) {
		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;

		return this.chunkArray[xc][zc].getRawBrightness(x & 15, y, z & 15, this.worldObj.skyDarken);
	}

	@Unique
	public int getRawBrightnessMax(int x, int y, int z, int light) {
		int xc = (x >> 4) - this.chunkX;
		int zc = (z >> 4) - this.chunkZ;

		int returnValue = this.chunkArray[xc][zc].getRawBrightness(x & 15, y, z & 15, this.worldObj.skyDarken);

		return BitwiseMath.max(returnValue, light);
	}

	@Override
	public Chunk getChunk(int x, int y, int z) {
		if (y < 0 || y >= 256) {
			return null;
		}

		int chunkX = (x >> 4) - this.chunkX;
		int chunkZ = (z >> 4) - this.chunkZ;

		return this.chunkArray[chunkX][chunkZ];
	}
}

package net.safix.esotericvaccum.client.gl;

import org.lwjgl.opengl.GL20;

public class GlProgram {
	public int program;

	public GlProgram() {
		this.program = GL20.glCreateProgram();
	}

	public void attachShader(int shader) {
		GL20.glAttachShader(this.program, shader);
	}

	public void link() {
		GL20.glLinkProgram(this.program);
		GL20.glValidateProgram(this.program);
	}

	public void bindProgram() {
		GL20.glUseProgram(this.program);
	}

	public void unbindProgram() {
		GL20.glUseProgram(0);
	}
}

package net.safix.esotericvaccum.client.util;

import net.safix.esotericvaccum.client.rendering.meshing.IFaceWriteOrder;

public class BlockModelData {
	public float minX, maxX;
	public float minY, maxY;
	public float minZ, maxZ;

	public IFaceWriteOrder faceWriteOrder;

	public BlockModelData(float minX, float maxX, float minY, float maxY, float minZ, float maxZ) {
		this.minX = minX;
		this.maxX = maxX;

		this.minY = minY;
		this.maxY = maxY;

		this.minZ = minZ;
		this.maxZ = maxZ;
	}

	public BlockModelData(double minX, double maxX, double minY, double maxY, double minZ, double maxZ) {
		this.minX = (float) minX;
		this.maxX = (float) maxX;

		this.minY = (float) minY;
		this.maxY = (float) maxY;

		this.minZ = (float) minZ;
		this.maxZ = (float) maxZ;
	}
}

package net.safix.esotericvaccum.mixin.injection;

import net.minecraft.client.render.culling.Frustum;
import net.minecraft.client.render.culling.FrustumData;
import net.safix.esotericvaccum.client.JomlFrustum;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.*;

import java.nio.FloatBuffer;

@Mixin(value = FrustumData.class, remap = false)
public class MixinFrustrum {
	/**
	 * @author Safixo
	 * @reason Implement a simple
	 */
	@Overwrite
	public boolean cubeInFrustum(double x0, double y0, double z0, double x1, double y1, double z1) {
		return JomlFrustum.testAab((float) x0, (float) y0, (float) z0, (float) x1, (float) y1, (float) z1);
	}

	@Mixin(value = Frustum.class, remap = false)
	public static class MixinFrustumInit {
		@Shadow @Final private FloatBuffer _modl;
		@Shadow @Final private FloatBuffer _proj;
		@Unique private static final Matrix4f modelViewMatrix = new Matrix4f();
		@Unique private static final Matrix4f projectionMatrix = new Matrix4f();

		/**
		 * @author Safixo
		 * @reason Pass the matrix to our Frustrum.
		 */
		@Overwrite
		private void calculateFrustum() {
			this._proj.clear();
			this._modl.clear();

			GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, this._proj);
			GL11.glGetFloat(GL11.GL_MODELVIEW_MATRIX, this._modl);

			this._proj.rewind();
			this._modl.rewind();

			projectionMatrix.set(this._proj);
			modelViewMatrix.set(this._modl);
			projectionMatrix.mul(modelViewMatrix);

			JomlFrustum.passMatrix(projectionMatrix);
		}
	}
}


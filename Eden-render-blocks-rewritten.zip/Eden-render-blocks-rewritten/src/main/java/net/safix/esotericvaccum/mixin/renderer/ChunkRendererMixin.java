package net.safix.esotericvaccum.mixin.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.render.ChunkRenderer;
import net.minecraft.client.render.RenderBlocks;
import net.minecraft.client.render.TileEntityRenderDispatcher;
import net.minecraft.client.render.block.model.BlockModel;
import net.minecraft.client.render.block.model.BlockModelDispatcher;
import net.minecraft.client.render.block.model.BlockModelRenderBlocks;
import net.minecraft.client.render.culling.CameraFrustum;
import net.minecraft.core.block.Block;
import net.minecraft.core.block.entity.TileEntity;
import net.minecraft.core.world.World;
import net.minecraft.core.world.chunk.Chunk;
import net.minecraft.core.world.chunk.ChunkCache;
import net.minecraft.core.world.chunk.ChunkSection;
import net.safix.esotericvaccum.client.JomlFrustum;
import net.safix.esotericvaccum.client.gl.GlVertexBuffer;
import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
import net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection;
import net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirectionSet;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IChunkRenderer;
import net.safix.esotericvaccum.client.vertex.format.DefaultVertexFormats;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.ByteBuffer;
import java.util.List;

import static net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection.*;

@Mixin(value = ChunkRenderer.class, remap = false)
public abstract class ChunkRendererMixin implements IChunkRenderer {
	@Shadow public boolean needsUpdate;
	@Shadow public boolean[] skipRenderPass;

	@Shadow public int posX;
	@Shadow public int posY;
	@Shadow public int posZ;

	@Shadow public World worldObj;

	@Shadow public boolean isChunkLit;

	@Shadow private boolean isInitialized;

	@Shadow public List<TileEntity> specialTileEntities;

	@Shadow public int posXPlus;
	@Shadow public int posYPlus;
	@Shadow public int posZPlus;

	@Shadow public boolean isInFrustum;
	@Shadow public abstract void setDontDraw();
	@Shadow public abstract void markDirty();

	@Unique
	private int vertices = -1;

	@Unique
	public int faces;

	/**
	 * @author Safixo
	 * @reason Avoid indirection?
	 */
	@Overwrite
	public void updateInFrustum(CameraFrustum frustum, float partialTick) {
		Minecraft mc = Minecraft.getMinecraft(null);

		float offsetX = (float) mc.activeCamera.getX(partialTick);
		float offsetY = (float) mc.activeCamera.getY(partialTick);
		float offsetZ = (float) mc.activeCamera.getZ(partialTick);

		float minX = this.posX - offsetX;
		float minY = this.posY - offsetY;
		float minZ = this.posZ - offsetZ;

		float maxX = minX + 16.0F;
		float maxY = minY + 16.0F;
		float maxZ = minZ + 16.0F;

		this.isInFrustum = JomlFrustum.testAab(minX, minY, minZ, maxX, maxY, maxZ);
	}

	/**
	 * @author Safixo
	 * @reason Optimize position setting.
	 */
	@Overwrite
	public void setPosition(int x, int y, int z) {
		if (x != this.posX || y != this.posY || z != this.posZ) {
			this.setDontDraw();
			this.posX = x;
			this.posY = y;
			this.posZ = z;

			this.posXPlus = x + 8;
			this.posYPlus = y + 8;
			this.posZPlus = z + 8;

			this.markDirty();
		}
	}

	/**
	 * @author Safixo
	 * @reason Optimize and redirect Chunk meshing.
	 */
	@Overwrite
	public void updateRenderer() {
		for (int i = 0; i < 2; ++i) {
			this.skipRenderPass[i] = true;
		}

		Chunk.isLit = false;

		int minX = this.posX;
		int minY = this.posY;
		int minZ = this.posZ;

		int maxX = minX + 16;
		int maxY = minY + 16;
		int maxZ = minZ + 16;

		Chunk chunk = this.worldObj.getChunkFromBlockCoords(minX, minZ);
		ChunkSection section = chunk.getSection(minY >> 4);

		if (section.blocks == null) {
			return;
		}

		ChunkCache chunkCache = new ChunkCache(this.worldObj, minX - 1, minY - 1, minZ - 1, maxX + 1, maxY + 1, maxZ + 1);

		RenderBlocks renderBlocks = new RenderBlocks(this.worldObj, chunkCache);
		BlockModelRenderBlocks.setRenderBlocks(renderBlocks);

		int totalVertices = 0;
		int[] faces = new int[6];
		int lastBlockTotalVertices = 0;

		VertexWriterManager SOLID = VertexWriterManager.EMPTY_INSTANCE;
		VertexWriterManager TRANSLUCENT = VertexWriterManager.EMPTY_INSTANCE;

		final short[] blocks = section.blocks;

		int minMemoryForSolid = this.isInitialized ? Math.min(65536 >> 1, this.vertices * 26) : 768 * 24;

		for (int y = minY; y < maxY; y++) {
			for (int z = minZ; z < maxZ; z++) {
				for (int x = minX; x < maxX; x++) {
					int blockId = blocks[makeBlockIndex(x & 15, y & 15, z & 15)];

					if (blockId <= 0) {
						continue;
					}

					if (Block.isEntityTile[blockId]) {
						TileEntity tileentity = chunkCache.getBlockTileEntity(x, y, z);
						if (TileEntityRenderDispatcher.instance.hasRenderer(tileentity)) {
							this.specialTileEntities.add(tileentity);
						}
					}

					Block block = Block.blocksList[blockId];

					// Instead of instantly allocating memory, memory is allocated
					// only if needed and the amount depending on the render pass, as
					// translucent usually doesn't have as much geometry as solid.
					// Also last build data is used for allocating the necessary memory more exactly.
					if (block.getRenderBlockPass() == 1) {
						if (TRANSLUCENT == VertexWriterManager.EMPTY_INSTANCE) {
							TRANSLUCENT = new VertexWriterManager(248 * 24);
							this.prepareWriterForTerrain(TRANSLUCENT);
						}
						VertexWriterManager.setCurrentInstance(TRANSLUCENT);
					} else {
						if (SOLID == VertexWriterManager.EMPTY_INSTANCE) {
							SOLID = new VertexWriterManager(minMemoryForSolid);
							this.prepareWriterForTerrain(SOLID);
						}
						VertexWriterManager.setCurrentInstance(SOLID);
					}

					BlockModel model = BlockModelDispatcher.getInstance().getDispatch(block);
					model.render(block, x, y, z);
					if (block.hasOverbright) {
						renderBlocks.overbright = true;
						model.render(block, x, y, z);
						renderBlocks.overbright = false;
					}

					VertexWriterManager.setCurrentInstance(null);

					if (block.isSolidRender()) {
						final int xI = x - minX;
						final int yI = y - minY;
						final int zI = z - minZ;

						final int sign = lastBlockTotalVertices < SOLID.getVertices() ? 0 : 1;

						if (yI == 0) faces[DOWN] += shouldBeRendered(chunkCache, x, y, z, DOWN) | sign;
						if (yI == 15) faces[UP] += shouldBeRendered(chunkCache, x, y, z, UP) | sign;

						if (zI == 0) faces[NORTH] += shouldBeRendered(chunkCache, x, y, z, NORTH) | sign;
						if (zI == 15) faces[SOUTH] += shouldBeRendered(chunkCache, x, y, z, SOUTH) | sign;

						if (xI == 0) faces[WEST] += shouldBeRendered(chunkCache, x, y, z, WEST) | sign;
						if (xI == 15) faces[EAST] += shouldBeRendered(chunkCache, x, y, z, EAST) | sign;

					}
					lastBlockTotalVertices = SOLID.getVertices();
				}
			}
		}

		int visibleFaces = 0;

		for (int dir = 0; dir < COUNT; dir++)
			if (faces[dir] >= (16 * 16)) visibleFaces |= 1 << dir;

		// If all chunks faces are empty, don't even let the chunk send his mesh.
		if (visibleFaces == GraphDirectionSet.ALL) {
			SOLID.stopDrawing();
			TRANSLUCENT.stopDrawing();
			return;
		}

		this.faces = visibleFaces;

		this.skipRenderPass[0] = SOLID.getVertices() == 0;
		this.skipRenderPass[1] = TRANSLUCENT.getVertices() == 0;

		if (SOLID.getVertices() != 0) {
			int vertices = SOLID.getVertices();
			totalVertices += vertices;

			this.feedupBuffer(SOLID.getVertexData(), 0, vertices);
			SOLID.stopDrawing();
		}

		if (TRANSLUCENT.getVertices() != 0) {
			int vertices = TRANSLUCENT.getVertices();
			totalVertices += vertices;

			this.feedupBuffer(TRANSLUCENT.getVertexData(), 1, vertices);
			TRANSLUCENT.stopDrawing();
		}

		VertexWriterManager.setCurrentInstance(null);

		this.vertices = totalVertices;
		this.isChunkLit = Chunk.isLit;
		this.isInitialized = true;
	}

	@Unique
	private void prepareWriterForTerrain(VertexWriterManager writerManager) {
		writerManager.startDrawing();
		writerManager.setVertexFormat(DefaultVertexFormats.TERRAIN_FORMAT);
		writerManager.setPos(-this.posX, -this.posY, -this.posZ);
	}

	@Unique
	private int shouldBeRendered(ChunkCache chunkCache, int x, int y, int z, int dir) {
		return !chunkCache.isBlockOpaqueCube(x + GraphDirection.x(dir), y + GraphDirection.y(dir), z + GraphDirection.z(dir)) ? 0 : 1;
	}

	@Unique private GlVertexBuffer solidBuffer;
	@Unique private GlVertexBuffer translucentBuffer;


	@Inject(method = "reset", at = @At("TAIL"))
	public void reset(CallbackInfo ci) {
		if (this.solidBuffer != null) this.solidBuffer.clear();
		if (this.translucentBuffer != null) this.translucentBuffer.clear();
	}

	@Unique
	private void feedupBuffer(ByteBuffer vertexData, int renderPass, int vertices) {
		if (renderPass == 0) {
			if (this.solidBuffer == null) this.solidBuffer = new GlVertexBuffer(DefaultVertexFormats.TERRAIN_FORMAT);
			this.solidBuffer.upload(vertexData, vertices);
			vertexData.clear();
		} else {
			if (this.translucentBuffer == null) this.translucentBuffer = new GlVertexBuffer(DefaultVertexFormats.TERRAIN_FORMAT);
			this.translucentBuffer.upload(vertexData, vertices);
			vertexData.clear();
		}
	}

	@Unique
	private static int makeBlockIndex(int x, int y, int z) {
		return (y << 8) + (z << 4) + x;
	}

	@Override
	public GlVertexBuffer getBuffer(int renderPass) {
		return renderPass == 0 ? this.solidBuffer : this.translucentBuffer;
	}

	@Override
	public GlVertexBuffer getSolidBuffer() {
		return this.solidBuffer;
	}

	@Override
	public GlVertexBuffer getTranslucentBuffer() {
		return this.translucentBuffer;
	}

	@Override
	public int getVertices() {
		return this.vertices;
	}

	@Override
	public int getFaces() {
		return this.faces;
	}
}

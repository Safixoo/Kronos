package net.safix.esotericvaccum.client.rendering.chunk.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.render.RenderEngine;
import net.minecraft.client.render.RenderGlobal;
import net.safix.esotericvaccum.client.gl.GlVertexBuffer;
import org.lwjgl.opengl.GL30;

public class DefaultChunkRenderer extends RenderGlobal {
	private Minecraft minecraft;
	private RenderEngine renderEngine;

	public DefaultChunkRenderer(Minecraft minecraft, RenderEngine renderengine) {
		super(minecraft, renderengine);
		this.minecraft = minecraft;
		this.renderEngine = renderengine;
	}

//	private int renderSortedRenderers(int min, int max, int renderPass, double partialTick) {
//		int addedWorldRenderers = 0;
//
//		for (int i = min; i < max; i++) {
//			final SectionRenderer sectionRender = sections[i];
//			final GlVertexBuffer buffer = sectionRender.getBuffer(renderPass);
//
//			if (sectionRender.isInFrustum && !sectionRender.skipRenderPass[renderPass]) {
//				buffer.bindVAO();
//				buffer.draw();
//				if (renderPass == 0) addedWorldRenderers++;
//			}
//		}
//
//		GL30.glBindVertexArray(0);
//
//		return addedWorldRenderers;
//	}
}

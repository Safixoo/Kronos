package net.safix.esotericvaccum.mixin.data;

import net.minecraft.core.block.Block;
import net.minecraft.core.block.material.Material;
import net.minecraft.core.world.WorldSource;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IBlock;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.safix.esotericvaccum.client.util.math.BitwiseMath.smallestEncompassingPowerOfTwo;

@Mixin(value = Block.class, remap = false)
public abstract class MixinBlock implements IBlock {
	@Shadow protected boolean isLitInteriorSurface;
	@Shadow public double minX, minY, minZ, maxX, maxY, maxZ;

	@Final @Shadow @Mutable
	public static Block[] blocksList;

	@Final @Shadow @Mutable
	public static int[] lightEmission;

	static {
		int highestId = smallestEncompassingPowerOfTwo(Block.highestBlockId + 1);

		Block[] newBlocksList = new Block[highestId];
		System.arraycopy(blocksList, 0, newBlocksList, 0, Block.highestBlockId);
		blocksList = newBlocksList;

		int[] newEmissionLight = new int[highestId];
		System.arraycopy(lightEmission, 0, newEmissionLight, 0, Block.highestBlockId);
		lightEmission = newEmissionLight;
	}

	@Unique public boolean[] bounds = new boolean[7];

	@Inject(method = "setBlockBounds", at = @At("TAIL"))
	public void setBlockBounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, CallbackInfo ci) {
		this.bounds[0] = this.minY > 0.0;
		this.bounds[1] = this.maxY < 1.0;

		this.bounds[2] = this.minZ > 0.0;
		this.bounds[3] = this.maxZ < 1.0;

		this.bounds[4] = this.minX > 0.0;
		this.bounds[5] = this.maxX < 1.0;
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	public void setup(String key, int id, Material material, CallbackInfo ci) {
		this.bounds[0] = this.minY > 0.0;
		this.bounds[1] = this.maxY < 1.0;

		this.bounds[2] = this.minZ > 0.0;
		this.bounds[3] = this.maxZ < 1.0;

		this.bounds[4] = this.minX > 0.0;
		this.bounds[5] = this.maxX < 1.0;
	}

	@Override
	public boolean getLitInterior() {
		 return this.isLitInteriorSurface;
	}

	/**
	 * @author Safixo
	 * @reason Use primitives directly
	 */
	@Overwrite
	public boolean shouldSideBeRendered(WorldSource blockAccess, int x, int y, int z, int side) {
		int blockId = blockAccess.getBlockId(x, y, z);

		return side < 0 ? !Block.solid[blockId] : (this.bounds[side] || !Block.solid[blockId]);
	}
}

package net.safix.esotericvaccum.client.util.interfaces.mixin;

import net.minecraft.core.block.Block;
import net.minecraft.core.world.WorldSource;

public interface IRenderBlockCache {
	int getBrightnessInt(int relX, int relY, int relZ);
}

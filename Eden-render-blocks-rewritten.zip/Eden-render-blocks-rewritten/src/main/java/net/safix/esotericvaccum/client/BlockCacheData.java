package net.safix.esotericvaccum.client;

import net.minecraft.core.block.Block;
import net.minecraft.core.block.BlockLeavesBase;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IBlock;

import static net.safix.esotericvaccum.client.util.math.BitwiseMath.smallestEncompassingPowerOfTwo;

public class BlockCacheData {
	public static final boolean[] hasLightInterior = new boolean[smallestEncompassingPowerOfTwo(Block.highestBlockId + 1)];
	public static final boolean[] instanceOfLeaves = new boolean[smallestEncompassingPowerOfTwo(Block.highestBlockId + 1)];
	public static final int[] instanceOfLeavesBitwise = new int[smallestEncompassingPowerOfTwo(Block.highestBlockId + 1)];

	public static void cacheValues() {
		final int maxId = Block.highestBlockId;
		hasLightInterior[0] = true;

		for (int i = 0; i < maxId; i++) {
			Block block = Block.blocksList[i];

			if (block != null) {
				instanceOfLeaves[i] = block instanceof BlockLeavesBase;
				instanceOfLeavesBitwise[i] = instanceOfLeaves[i] ? (int) (0.2F * 0xFF) : Integer.MAX_VALUE;

				hasLightInterior[i] = ((IBlock)block).getLitInterior();
			}
		}
	}
}

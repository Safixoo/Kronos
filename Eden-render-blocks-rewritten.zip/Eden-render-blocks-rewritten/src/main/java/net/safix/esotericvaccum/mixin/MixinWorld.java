package net.safix.esotericvaccum.mixin;

import net.minecraft.core.block.Block;
import net.minecraft.core.entity.Entity;
import net.minecraft.core.util.phys.AABB;
import net.minecraft.core.world.World;
import net.minecraft.core.world.chunk.Chunk;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IChunkCache;
import org.spongepowered.asm.mixin.*;

import java.util.ArrayList;
import java.util.List;

@Mixin(value = World.class, remap = false)
public abstract class MixinWorld implements IChunkCache {
	@Shadow public abstract int getBlockId(int x, int y, int z);
	@Shadow @Final public ArrayList<AABB> collidingBoundingBoxes;
	@Shadow public abstract int getBlockMetadata(int x, int y, int z);

	@Shadow @Final private List<Entity> entityBuffer;
	@Shadow public abstract Chunk getChunkFromChunkCoords(int x, int z);
	@Shadow public abstract boolean isChunkLoaded(int x, int z);
	@Override public Chunk getChunk(int x, int y, int z) {
		return this.getChunk(x, y, z);
	}

	@Override
	public boolean getSolidUnsafe(int x, int y, int z) {
		return Block.solid[this.getBlockId(x, y, z)];
	}

	/**
	 * @author Safixo
	 * @reason Faster
	 */
	@Overwrite
	public List<AABB> getCubes(Entity entity, AABB axisalignedbb) {
		this.collidingBoundingBoxes.clear();
		int minX = (int)(axisalignedbb.minX);
		int maxX = (int)(axisalignedbb.maxX + 1.0);
		int minY = (int)(axisalignedbb.minY);
		int maxY = (int)(axisalignedbb.maxY + 1.0);
		int minZ = (int)(axisalignedbb.minZ);
		int maxZ = (int)(axisalignedbb.maxZ + 1.0);

		for (int dx = minX - 1; dx <= maxX; ++dx) {
			for (int dz = minZ - 1; dz <= maxZ; ++dz) {
				if (this.isBlockLoaded(dx, dz)) {
					for(int dy = minY - 1; dy <= maxY; ++dy) {
						Block block = Block.blocksList[this.getBlockId(dx, dy, dz)];
						if (block != null) {
							int metadata = this.getBlockMetadata(dx, dy, dz);
							if (block.collidesWithEntity(entity) && entity.collidesWithBlock(block, metadata)) {
								block.getCollidingBoundingBoxes((World) (Object)this, dx, dy, dz, axisalignedbb, this.collidingBoundingBoxes);
							}
						}
					}
				}
			}
		}

		List<Entity> list = this.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb.expand(0.25, 0.25, 0.25));

        for (Entity value : list) {
            AABB axisalignedbb1 = value.getBb();
            if (axisalignedbb1 != null && axisalignedbb1.intersectsWith(axisalignedbb)) {
                this.collidingBoundingBoxes.add(axisalignedbb1);
            }
        }

		return this.collidingBoundingBoxes;
	}

	@Unique
	private boolean isBlockLoaded(int x, int z) {
		return this.isChunkLoaded(x >> 4, z >> 4);
	}


	@Unique
	private List<Entity> getEntitiesWithinAABBExcludingEntity(Entity entity, AABB aabb) {
		this.entityBuffer.clear();
		int minX = (int) aabb.minX >> 4;
		int maxX = (int) aabb.maxX >> 4;
		int minZ = (int) aabb.minZ >> 4;
		int maxZ = (int) aabb.maxZ >> 4;

		for(int x = minX; x <= maxX; ++x) {
			for(int z = minZ; z <= maxZ; ++z) {
				if (this.isChunkLoaded(x, z)) {
					this.getChunkFromChunkCoords(x, z).getEntitiesWithin(entity, aabb, this.entityBuffer);
				}
			}
		}

		return this.entityBuffer;
	}
}

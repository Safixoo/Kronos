package net.safix.esotericvaccum.client.util.interfaces.mixin;

public interface IAurora {
	float getValue(float x, float y, float z);
}

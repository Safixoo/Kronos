package net.safix.esotericvaccum.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value = Minecraft.class, remap = false)
public abstract class MixinMinecraft {
	@Shadow private static Minecraft INSTANCE;

	/**
	 * @author Safixo
	 * @reason Maybe I shouldn't do this?
	 */
	@Overwrite
	public static Minecraft getMinecraft(Class<?> caller) {
		return INSTANCE;
	}
}

package net.safix.esotericvaccum.client.rendering.cull.graph;

import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import net.safix.esotericvaccum.client.JomlFrustum;
import net.safix.esotericvaccum.client.rendering.cull.ChunkOcclusionData;
import net.safix.esotericvaccum.client.rendering.cull.chunk.ChunkGraphNode;
import org.joml.Vector3f;

public interface ChunkCuller {
    ReferenceArrayList<ChunkGraphNode> computeVisible(Vector3f cameraPos, JomlFrustum frustum, int frame, boolean spectator);

    void onSectionStateChanged(int x, int y, int z, ChunkOcclusionData occlusionData);
    void onSectionLoaded(int x, int y, int z, int id);
    void onSectionUnloaded(int x, int y, int z);

    boolean isSectionVisible(int x, int y, int z);
}

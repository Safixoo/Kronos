package net.safix.esotericvaccum.client.rendering.cull;

import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import net.minecraft.client.render.ChunkRenderer;
import net.minecraft.core.world.World;
import net.minecraft.core.world.chunk.Chunk;
import net.safix.esotericvaccum.client.JomlFrustum;
import net.safix.esotericvaccum.client.rendering.cull.chunk.ChunkGraphColumn;
import net.safix.esotericvaccum.client.rendering.cull.chunk.ChunkGraphNode;
import net.safix.esotericvaccum.client.rendering.cull.direction.Direction;
import net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection;
import net.safix.esotericvaccum.client.rendering.cull.graph.ChunkGraphCuller;
import net.safix.esotericvaccum.client.rendering.cull.position.ChunkPos;
import net.safix.esotericvaccum.client.rendering.cull.util.IdTable;
import org.joml.Vector3f;

public class ChunkRenderManager {
    private final Long2ObjectOpenHashMap<ChunkGraphColumn> columns = new Long2ObjectOpenHashMap<>();
    private final IdTable<ChunkRenderer> renders = new IdTable<>(16384);

    private final ChunkGraphCuller culler;
    private boolean dirty;
	public static ChunkRenderManager INSTANCE;

    public ChunkRenderManager(World world, int renderDistance) {
        this.culler = new ChunkGraphCuller(world, renderDistance);
		INSTANCE = this;
    }

    public void onChunkAdded(int x, int z) {
        this.loadChunk(x, z);
    }

    public void onChunkRemoved(int x, int z) {
        this.unloadChunk(x, z);
    }

    private void loadChunk(int x, int z) {
        ChunkGraphColumn column = new ChunkGraphColumn(x, z);
        ChunkGraphColumn prev;

        if ((prev = this.columns.put(ChunkPos.toLong(x, z), column)) != null) {
            this.unloadSections(prev);
        }

        this.connectNeighborColumns(column);
        this.loadSections(column);

        this.dirty = true;
    }

	public static ReferenceArrayList<ChunkGraphNode> startCulling(Vector3f cameraPos, JomlFrustum frustum, int frame) {
		return INSTANCE.culler.computeVisible(cameraPos, frustum, frame, false);
	}

	public void onChunkRenderUpdates(int x, int y, int z, ChunkOcclusionData data) {
		this.culler.onSectionStateChanged(x, y, z, data);
	}

	public static void clear() {
		INSTANCE.culler.visible.clear();
	}

    private void unloadChunk(int x, int z) {
        ChunkGraphColumn column = this.columns.remove(ChunkPos.toLong(x, z));

        if (column == null) {
            return;
        }

        this.disconnectNeighborColumns(column);
        this.unloadSections(column);

        this.dirty = true;
    }

    private void loadSections(ChunkGraphColumn column) {
        int x = column.getX();
        int z = column.getZ();

        for (int y = 0; y < 16; y++) {
            this.culler.onSectionLoaded(x, y, z, 0);
        }
    }

    private void unloadSections(ChunkGraphColumn column) {
        int x = column.getX();
        int z = column.getZ();

        for (int y = 0; y < 16; y++) {
            this.culler.onSectionUnloaded(x, y, z);
        }
    }

    private void connectNeighborColumns(ChunkGraphColumn column) {
        for (int dir = 0; dir < GraphDirection.COUNT; dir++) {
            ChunkGraphColumn adj = this.getAdjacentColumn(column, GraphDirection.toEnum(dir));

            if (adj != null) {
                adj.setAdjacentColumn(GraphDirection.opposite(dir), column);
            }

            column.setAdjacentColumn(dir, adj);
        }
    }

    private void disconnectNeighborColumns(ChunkGraphColumn column) {
        for (int dir = 0; dir < GraphDirection.COUNT; dir++) {
            ChunkGraphColumn adj = column.getAdjacentColumn(dir);

            if (adj != null) {
                adj.setAdjacentColumn(GraphDirection.opposite(dir), null);
            }

            column.setAdjacentColumn(dir, null);
        }
    }

    private ChunkGraphColumn getAdjacentColumn(ChunkGraphColumn column, Direction dir) {
        return this.getColumn(column.getX() + dir.offsetX, column.getZ() + dir.offsetZ);
    }

	public void restoreChunks(ChunkRenderer[] renders) {
		for (ChunkRenderer cr : renders) {
			this.loadChunk(cr.posX, cr.posZ);
		}
	}

    private ChunkGraphColumn getColumn(int x, int z) {
        return this.columns.get(ChunkPos.toLong(x, z));
    }
}

package net.safix.esotericvaccum.client.util;

public class FogHelper {

	private static float fogDistance;

	public static void passFogDistance(float fogDistance) {
		FogHelper.fogDistance = fogDistance;
	}

	public static float getFogDistance() {
		return fogDistance;
	}
}

package net.safix.esotericvaccum.client.rendering.cull.direction;


import org.joml.Vector3f;

public enum ModelQuadFacing {
    UP,
    DOWN,
    EAST,
    WEST,
    SOUTH,
    NORTH,
    UNASSIGNED;

    public static final ModelQuadFacing[] VALUES = ModelQuadFacing.values();
    public static final int COUNT = VALUES.length;
    public static final ModelQuadFacing[] OPPOSITE;

    static {
        OPPOSITE = new ModelQuadFacing[6];
        OPPOSITE[DOWN.ordinal()] = UP;
        OPPOSITE[UP.ordinal()] = DOWN;
        OPPOSITE[NORTH.ordinal()] = SOUTH;
        OPPOSITE[SOUTH.ordinal()] = NORTH;
        OPPOSITE[WEST.ordinal()] = EAST;
        OPPOSITE[EAST.ordinal()] = WEST;
    }


    public static ModelQuadFacing fromDirection(ModelQuadFacing dir) {
        switch (dir) {
            case DOWN:
                return ModelQuadFacing.DOWN;
            case UP:
                return ModelQuadFacing.UP;
            case NORTH:
                return ModelQuadFacing.NORTH;
            case SOUTH:
                return ModelQuadFacing.SOUTH;
            case WEST:
                return ModelQuadFacing.WEST;
            case EAST:
                return ModelQuadFacing.EAST;
            default: return null;
        }
    }

    public static ModelQuadFacing toDirection(ModelQuadFacing dir) {
        switch (dir) {
            case DOWN:
                return ModelQuadFacing.DOWN;
            case UP:
                return ModelQuadFacing.UP;
            case NORTH:
                return ModelQuadFacing.NORTH;
            case SOUTH:
                return ModelQuadFacing.SOUTH;
            case WEST:
                return ModelQuadFacing.WEST;
            case EAST:
                return ModelQuadFacing.EAST;
            default: return null;
        }
    }

    public static ModelQuadFacing fromVector(Vector3f normal) {
        if(normal.x == 0f) {
            if(normal.y == 0f) {
                if(normal.z > 0) {
                    return SOUTH;
                } else if(normal.z < 0) {
                    return NORTH;
                }
            } else if(normal.z == 0f) {
                if(normal.y > 0) {
                    return UP;
                } else if(normal.y < 0) {
                    return DOWN;
                }
            }
        } else if(normal.y == 0f && (normal.z == 0f)) {
            if(normal.x > 0) {
                return EAST;
            } else if(normal.x < 0) {
                return WEST;
            }
        }
        return UNASSIGNED;
    }

    public ModelQuadFacing getOpposite() {
        return OPPOSITE[this.ordinal()];
    }
}

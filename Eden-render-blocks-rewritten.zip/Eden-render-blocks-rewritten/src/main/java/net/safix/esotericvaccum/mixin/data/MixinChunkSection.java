package net.safix.esotericvaccum.mixin.data;

import net.minecraft.core.enums.LightLayer;
import net.minecraft.core.world.chunk.ChunkSection;
import net.minecraft.core.world.data.ChunkNibbleArray;
import net.minecraft.core.world.data.ChunkUnsignedByteArray;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value = ChunkSection.class, remap = false)
public abstract class MixinChunkSection {
	@Shadow public short[] blocks;
	@Shadow public ChunkNibbleArray skylightMap;
	@Shadow public ChunkNibbleArray blocklightMap;

	@Shadow
	public ChunkUnsignedByteArray data;

	/**
	 * @author Safixo
	 * @reason Avoid many checks
	 */
	@Overwrite
	public int getBlock(int x, int y, int z) {
		return this.blocks == null ? 0 : this.blocks[makeBlockIndex(x, y, z)] & 16383;
	}

	/**
	 * @author Safixo
	 * @reason Make intention clearer and faster using Bitwise-Math.
	 */
	@Overwrite
	public static int makeBlockIndex(int x, int y, int z) {
		return (y << 8) + (z << 4) + x;
	}

	/**
	 * @author Safixo
	 * @reason Avoid many checks
	 */
	@Overwrite
	public int getRawBrightness(int x, int y, int z, int skySubtract) {
		return Math.max(this.getSkyBrightness(x, y, z) - skySubtract, this.getBlockBrightness(x, y, z));
	}

	@Unique
	private int getSkyBrightness(int x, int y, int z) {
		if (this.skylightMap != null) {
			return this.skylightMap.get(x, y, z);
		}
		return 0;
	}

	@Unique
	private int getBlockBrightness(int x, int y, int z) {
		if (this.blocklightMap != null) {
			return this.blocklightMap.get(x, y, z);
		}
		return 0;
	}

	/**
	 * @author Safixo
	 * @reason Avoid many checks
	 */
	@Overwrite
	public int getBrightness(LightLayer layer, int x, int y, int z) {
		if (layer == LightLayer.Sky) {
			if (this.skylightMap != null) {
				return this.skylightMap.get(x, y, z);
			}
			return 0;
		}

		if (this.blocklightMap != null) {
			return this.blocklightMap.get(x, y, z);
		}

		return 0;
	}


	/**
	 * @author Safixo
	 * @reason Avoid excessive bounds checking.
	 */
	@Overwrite
	public int getData(int x, int y, int z) {
		return this.blocks != null && this.data != null ? this.data.get(x, y, z) : 0;
	}
}

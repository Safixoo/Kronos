package net.safix.esotericvaccum.client.gl;

import net.safix.esotericvaccum.Eden;
import org.lwjgl.opengl.GL20;

public class GlShader {
	private final int shader;
	private String shaderSource;

	public static int VERTEX_SHADER = GL20.GL_VERTEX_SHADER, FRAGMENT_SHADER = GL20.GL_FRAGMENT_SHADER;

	public GlShader(int type) {
		this.shader = GL20.glCreateShader(type);
	}

	public void compileSource() {

	}

	public static void check() {
	}

	public int getId() {
		return this.shader;
	}

	public void compileShader() {
		GL20.glShaderSource(this.shader, this.shaderSource);
		GL20.glCompileShader(this.shader);

		String error = GL20.glGetShaderInfoLog(this.shader, 500);

		if (!error.isEmpty()) {
			Eden.LOGGER.error(error);
			Eden.LOGGER.error("Error! Something failed in the shader compilation, see above the compilation error");
		}
	}
}

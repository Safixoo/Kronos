package net.safix.esotericvaccum.client.vertex.format;

import com.google.common.collect.ImmutableList;
import net.safix.esotericvaccum.client.util.interfaces.IVertexWriter;

import java.nio.ByteBuffer;

public class VertexFormat {
	private final ImmutableList<VertexProperty> vertexProperties;
	private final int STRIDE;
	private final IVertexWriter writer;

	public VertexFormat(ImmutableList<VertexProperty> vertexProperties, IVertexWriter writer) {
		int stride = 0;

		for (int i = 0, size = vertexProperties.size(); i < size; i++) {
			VertexProperty vertexProperty = vertexProperties.get(i);
			stride += vertexProperty.getAmount() * vertexProperty.getSize();
		}

		// align to 4-bytes.
		if ((stride & 3) > 0) {
			stride += 4 - stride & 3;
		}

		STRIDE = stride;
		this.writer = writer;
		this.vertexProperties = vertexProperties;
	}

	public void writeVertex(ByteBuffer data, int index) {
		this.writer.writeVertex(data, index);
	}

	public void setupBufferState() {
		int offset = 0;
		for (VertexProperty vertexProperty : vertexProperties) {
			vertexProperty.getOperation().setupBufferState(vertexProperty.getAmount(), vertexProperty.getType(), STRIDE, offset);
			offset += vertexProperty.getAmount() * vertexProperty.getSize();
		}
	}

	public void cleanupBufferState() {
		for (VertexProperty vertexProperty : vertexProperties) {
			vertexProperty.getOperation().cleanupBufferState();
		}
	}

	public int getStride() {
		return STRIDE;
	}
}

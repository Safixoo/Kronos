package net.safix.esotericvaccum.mixin;

import net.minecraft.core.util.helper.MathHelper;
import net.minecraft.core.world.noise.BaseImprovedNoise;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IAurora;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(value = BaseImprovedNoise.class, remap = false)
public abstract class MixinImprovedNoise implements IAurora {
	@Shadow @Final protected int[] p;

	@Unique
	private final int[] PV = new int[512];

	@Inject(method = "<init>", at = @At("TAIL"))
	private void feedArray(Random random, CallbackInfo ci) {
		int index = 0;

		for (int value : this.p) {
			PV[index++] = value;
		}
	}

	@Override
	public float getValue(float x, float y, float z) {
		int X = MathHelper.floor_float(x);
		int Y = MathHelper.floor_float(y);
		int Z = MathHelper.floor_float(z);

		x -= X;
		y -= Y;
		z -= Z;

		X &= 255;
		Y &= 255;
		Z &= 255;

		float u = fade(x);
		float v = fade(y);
		float w = fade(z);

		int A = PV[X] + Y;
		int AA = PV[A] + Z;
		int AB = PV[A + 1] + Z;
		int B = PV[X + 1] + Y;
		int BA = PV[B] + Z;
		int BB = PV[B + 1] + Z;

		return lerp(w, lerp(v, lerp(u, grad(PV[AA], x, y, z), grad(PV[BA], x - 1.0F, y, z)), lerp(u, grad(PV[AB], x, y - 1.0F, z), grad(PV[BB], x - 1.0F, y - 1.0F, z))), lerp(v, lerp(u, grad(PV[AA + 1], x, y, z - 1.0F), grad(PV[BA + 1], x - 1.0F, y, z - 1.0F)), lerp(u, grad(PV[AB + 1], x, y - 1.0F, z - 1.0F), grad(PV[BB + 1], x - 1.0F, y - 1.0F, z - 1.0F))));
	}

	@Unique
	private static final Vector3f[] GRADIENTS = {
		new Vector3f(1, 1, 0), new Vector3f(-1, 1, 0), new Vector3f(1, -1, 0), new Vector3f(-1, -1, 0),
		new Vector3f(1, 0, 1), new Vector3f(-1, 0, 1), new Vector3f(1, 0, -1), new Vector3f(-1, 0, -1),
		new Vector3f(0, 1, 1), new Vector3f(0, -1, 1), new Vector3f(0, 1, -1), new Vector3f(0, -1, -1),
		new Vector3f(1, 1, 0), new Vector3f(-1, 1, 0), new Vector3f(0, -1, 1), new Vector3f(0, -1, -1)
	};

	@Unique
	private static float grad(int hash, float x, float y, float z) {
		Vector3f gradient = GRADIENTS[hash & 15];
		return gradient.x * x + gradient.y * y + gradient.z * z;
	}

	@Unique
	private static float lerp(float t, float a, float b) {
		return a + t * (b - a);
	}

	@Unique
	private static float fade(float t) {
		return t * t * t * (t * (t * 6.0F - 15.0F) + 10.0F);
	}
}

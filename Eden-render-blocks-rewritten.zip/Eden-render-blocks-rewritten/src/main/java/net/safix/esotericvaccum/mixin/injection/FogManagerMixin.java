package net.safix.esotericvaccum.mixin.injection;

import net.minecraft.client.Minecraft;
import net.minecraft.client.option.enums.RenderDistance;
import net.minecraft.client.render.FogManager;
import net.safix.esotericvaccum.client.util.FogHelper;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = FogManager.class, remap = false)
public class FogManagerMixin {
	@Shadow
	@Final
	public Minecraft mc;

	@Inject(method = "setupFog", at = @At("TAIL"))
	private void getFogDistance(int fogMode, float farPlaneDistance, float partialTick, CallbackInfo ci) {
		float maxFogDistance = (float)(RenderDistance.EXTREME.chunks * 16);
		float fogDistance = farPlaneDistance;
		float fogModifier = this.mc.theWorld.getCurrentWeather() != null ? this.mc.theWorld.getCurrentWeather().fogDistance : 1.0F;
		fogModifier = 1.0F - (1.0F - fogModifier) * this.mc.theWorld.weatherManager.getWeatherIntensity() * this.mc.theWorld.weatherManager.getWeatherPower();
		if (farPlaneDistance > maxFogDistance * fogModifier) {
			fogDistance = maxFogDistance * fogModifier;
		}

		FogHelper.passFogDistance(fogDistance + 16.0F);
	}
}

package net.safix.esotericvaccum.client.rendering.cull.position;

import net.minecraft.core.world.chunk.ChunkCoordinate;
import net.minecraft.core.world.chunk.ChunkPosition;
import net.safix.esotericvaccum.client.rendering.ChunkSectionPos;
import net.safix.esotericvaccum.client.rendering.cull.direction.Direction;
import org.joml.Vector3i;

public class BlockPos extends Vector3i  {

	public BlockPos() {
		super();
	}

	public BlockPos(int x, int y, int z) {
		super(x, y, z);
	}

	public BlockPos(ChunkPosition chunkPosition) {
		super(chunkPosition.x, chunkPosition.y, chunkPosition.z);
	}


	public int getX() {
		return this.x;
	}


	public int getY() {
		return this.y;
	}


	public int getZ() {
		return this.z;
	}


	public BlockPos offset(Direction d) {
		return new BlockPos(this.x + d.offsetX, this.y + d.offsetY, this.z + d.offsetZ);
	}


	public BlockPos down() {
		return offset(Direction.DOWN);
	}


	public BlockPos up() {
		return offset(Direction.UP);
	}


	public long asLong() {
		return ChunkSectionPos.asLong(this.x, this.y, this.z);
	}

	public BlockPos set(int x, int y, int z) {
		super.set(x, y, z);
		return this;
	}
}

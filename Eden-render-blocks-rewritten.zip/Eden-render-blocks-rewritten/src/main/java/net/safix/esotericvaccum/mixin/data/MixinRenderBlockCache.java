package net.safix.esotericvaccum.mixin.data;

import net.minecraft.client.Minecraft;
import net.minecraft.client.render.RenderBlockCache;
import net.minecraft.core.block.Block;
import net.minecraft.core.world.WorldSource;
import net.safix.esotericvaccum.client.BlockCacheData;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IRenderBlockCache;
import net.safix.esotericvaccum.client.util.math.BitwiseMath;
import org.spongepowered.asm.mixin.*;

@Mixin(value = RenderBlockCache.class, remap = false)
public class MixinRenderBlockCache implements IRenderBlockCache {
	@Shadow private WorldSource access;
	@Shadow private int offsetZ;
	@Shadow private int offsetY;
	@Shadow private int offsetX;
	@Shadow private Block block;

	@Shadow @Final private boolean[] brightnessCached;
	@Shadow @Final private boolean[] opacityCached;
	@Shadow @Final private boolean[] opacityValue;
	@Shadow @Final private float[] brightnessValue;
	@Shadow @Final private Minecraft mc;

	/**
	 * @author Safixo
	 * @reason Faster brightness pulling
	 */
	@Overwrite
	public float getBrightness(int relX, int relY, int relZ) {
		int blockId = this.access.getBlockId(relX + this.offsetX, relY + this.offsetY, relZ + this.offsetZ);

		if (!(!this.mc.fullbright || Block.solid[blockId])) {
			return 1.0F;
		}

		if (BlockCacheData.instanceOfLeaves[blockId]) {
			int index = (relX + 1) * 9 + (relY + 1) * 3 + relZ + 1;

			if (!this.brightnessCached[index]) {
				this.brightnessValue[index] = this.block.getBlockBrightness(this.access, relX + this.offsetX, relY + this.offsetY, relZ + this.offsetZ);
				this.brightnessCached[index] = true;
			}

			return Math.min(this.brightnessValue[index], 0.2F);
		}

		int index = (relX + 1) * 9 + (relY + 1) * 3 + relZ + 1;
		if (!this.brightnessCached[index]) {
			this.brightnessValue[index] = this.block.getBlockBrightness(this.access, relX + this.offsetX, relY + this.offsetY, relZ + this.offsetZ);
			this.brightnessCached[index] = true;
		}

		return this.brightnessValue[index];
	}

	/**
	 * @author Safixo
	 * @reason Faster opacity pulling.
	 */
	@Overwrite
	public boolean getOpacity(int relX, int relY, int relZ) {
		final int index = (relX + 1) * 9 + (relY + 1) * 3 + relZ + 1;

		if (!this.opacityCached[index]) {
			this.opacityValue[index] = Block.solid[this.access.getBlockId(relX + this.offsetX, relY + this.offsetY, relZ + this.offsetZ)];
			this.opacityCached[index] = true;
		}

		return this.opacityValue[index];
	}

	@Unique
	private static final boolean[] DEFAULT = new boolean[27];

	/**
	 * @author Safixo
	 * @reason Optimize array fill by copying an array with intrinsics.
	 */
	@Overwrite
	public void setupCache(Block block, WorldSource access, int x, int y, int z) {
		this.block = block;
		this.access = access;
		this.offsetX = x;
		this.offsetY = y;
		this.offsetZ = z;
		System.arraycopy(DEFAULT, 0, this.brightnessCached, 0, 27);
		System.arraycopy(DEFAULT, 0, this.opacityCached, 0, 27);
	}


//
// --------------------------------------------------
// METHODS FOR FAST-PATH ALTERNATIVE OF BLOCK MESHING.
// --------------------------------------------------
//

	@Unique
	private final int[] brightnessValueInt = new int[27];

	@Override
	public int getBrightnessInt(int relX, int relY, int relZ) {
		final int index = (relX + 1) * 9 + (relY + 1) * 3 + relZ + 1;

		if (!this.brightnessCached[index]) {
			this.brightnessValueInt[index] = (int) (this.block.getBlockBrightness(this.access, relX + this.offsetX, relY + this.offsetY, relZ + this.offsetZ) * 0xFF);
			this.brightnessCached[index] = true;
		}

		return this.brightnessValueInt[index];
	}
}

package net.safix.esotericvaccum.mixin;

import net.safix.esotericvaccum.client.util.interfaces.mixin.IFrustum;
import org.joml.FrustumIntersection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value = FrustumIntersection.class, remap = false)
public class MixinJomlFrustum implements IFrustum {
	@Shadow private float nxX;
	@Shadow private float nxY;
	@Shadow private float nxZ;
	@Shadow private float pxX;
	@Shadow private float pxY;
	@Shadow private float pxZ;
	@Shadow private float nyX;
	@Shadow private float nyY;
	@Shadow private float nyZ;
	@Shadow private float pyX;
	@Shadow private float pyY;
	@Shadow private float pyZ;

	@Override
	public boolean testAabSimpler(float minX, float minY, float minZ) {
		return  (nxX * minX + nxY * minY + nxZ * minZ) >= 0 && (pxX * minX + pxY * minY + pxZ * minZ) >= 0 &&
				(nyX * minX + nyY * minY + nyZ * minZ >= 0 && (pyX * minX + pyY * minY + pyZ * minZ) >= 0);
	}

	@Override
	public boolean testAabFasterInt(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
		return  nxX * (maxX + (minX & g(0))) + nxY * (maxY + (minY & g(1)))  + nxZ * (maxZ + (minZ & g(2)))  >= 0 &&
			    pxX * (maxX + (minX & g(3))) + pxY * (maxY + (minY & g(4)))  + pxZ * (maxZ + (minZ & g(5)))  >= 0 &&
			    nyX * (maxX + (minX & g(6))) + nyY * (maxY + (minY & g(7)))  + nyZ * (maxZ + (minZ & g(8)))  >= 0 &&
			    pyX * (maxX + (minX & g(9))) + pyY * (maxY + (minY & g(10))) + pyZ * (maxZ + (minZ & g(11))) >= 0;
	}

	@Unique
	private int BITMASK;

	@Unique
	private int g(int index) {
		return -(BITMASK >>> index & 1);
	}

	@Override
	public boolean testAabFasterFloat(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
		return nxX * (nxX < 0 ? minX : maxX) + nxY * (nxY < 0 ? minY : maxY) + nxZ * (nxZ < 0 ? minZ : maxZ) >= 0 &&
		    	pxX * (pxX < 0 ? minX : maxX) + pxY * (pxY < 0 ? minY : maxY) + pxZ * (pxZ < 0 ? minZ : maxZ) >= 0 &&
		       	nyX * (nyX < 0 ? minX : maxX) + nyY * (nyY < 0 ? minY : maxY) + nyZ * (nyZ < 0 ? minZ : maxZ) >= 0 &&
		     	pyX * (pyX < 0 ? minX : maxX) + pyY * (pyY < 0 ? minY : maxY) + pyZ * (pyZ < 0 ? minZ : maxZ) >= 0;
	}

	@Override
	public void preComputeData() {
		BITMASK = 0x0;
		BITMASK |= nxX < 0 ? 1 << 0  : 0;
		BITMASK |= nxY < 0 ? 1 << 1  : 0;
		BITMASK |= nxZ < 0 ? 1 << 2  : 0;
		BITMASK |= pxX < 0 ? 1 << 3  : 0;
		BITMASK |= pxY < 0 ? 1 << 4  : 0;
		BITMASK |= pxZ < 0 ? 1 << 5  : 0;
		BITMASK |= nyX < 0 ? 1 << 6  : 0;
		BITMASK |= nyY < 0 ? 1 << 7  : 0;
		BITMASK |= nyZ < 0 ? 1 << 8  : 0;
		BITMASK |= pyX < 0 ? 1 << 9  : 0;
		BITMASK |= pyY < 0 ? 1 << 10 : 0;
		BITMASK |= pyZ < 0 ? 1 << 11 : 0;
    }
}


package net.safix.esotericvaccum.mixin.renderer;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.render.ChunkRenderer;
import net.minecraft.client.render.RenderGlobal;
import net.minecraft.client.render.camera.ICamera;
import net.minecraft.client.render.culling.CameraFrustum;
import net.minecraft.core.world.World;
import net.safix.esotericvaccum.client.JomlFrustum;
import net.safix.esotericvaccum.client.gl.GlShader;
import net.safix.esotericvaccum.client.gl.GlVertexBuffer;
import net.safix.esotericvaccum.client.rendering.cull.direction.GraphDirection;
import net.safix.esotericvaccum.client.util.math.BitwiseMath;
import net.safix.esotericvaccum.client.util.FogHelper;
import net.safix.esotericvaccum.client.util.interfaces.mixin.IChunkRenderer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Random;

@Mixin(value = RenderGlobal.class, remap = false)
public class RenderGlobalMixin {
	@Shadow private ChunkRenderer[] sortedChunkRenderers;
	@Shadow private Minecraft mc;
	@Shadow private int renderersBeingRendered;

	@Shadow
	private World worldObj;
	@Unique
	private boolean shaderCreated = false;

	/**
	 * @author Safixo
	 * @reason Replace display-lists with VBO with VAO.
	 */
	@Overwrite
	private int renderSortedRenderers(int min, int max, int renderPass, double partialTick) {
		int addedWorldRenderers = 0;

		// Disables fog when option is active.
		if (!this.mc.gameSettings.fog.value) {
			GL11.glDisable(GL11.GL_FOG);
		}

		// Look like terrain display lists have some of these states baked.
		// With my VBO rendering this isn't the case.
		if (renderPass == 1) {
			GL11.glColorMask(true, true, true, true);
			GL11.glEnable(GL11.GL_CULL_FACE);
		}

		final float camX = (float) this.mc.activeCamera.getX((float)partialTick);
		final float camY = (float) this.mc.activeCamera.getY((float)partialTick);
		final float camZ = (float) this.mc.activeCamera.getZ((float)partialTick);

		if (!this.shaderCreated) {
			this.prepareAndCompileShader();
		}

		GL20.glUseProgram(this.programId);

		this.setupUniforms(camX, camY, camZ);

		// Translate terrain based on player position.

		// Renders the front-to-back in solid and back-to-front in
		// translucent.
		if (renderPass == 0) {
			for (int i = 0; i < this.renderList.size(); i++) {
				this.renderSolidTerrain(i);
			}
		} else {
			for (int i = this.renderList.size() - 1; i > -1; i--) {
				this.renderTranslucentTerrain(i);
			}
		}

		GL30.glBindVertexArray(0);

		GL20.glUseProgram(0);

		if (this.mc.gameSettings.fog.value) {
			GL11.glEnable(GL11.GL_FOG);
		}

		return addedWorldRenderers;
	}

	private int vertexShaderId;
	private int fragmentShaderId;

	private int programId;

	@Unique
	private int tex, camPos;

	@Unique
	public void prepareAndCompileShader() {
		this.programId = GL20.glCreateProgram();
		this.vertexShaderId = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
		this.fragmentShaderId = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);

		GL20.glShaderSource(this.vertexShaderId, vertexShader);
		GL20.glShaderSource(this.fragmentShaderId, fragmentShader);

		GL20.glCompileShader(this.vertexShaderId);

		System.out.println("\nVertex Shader Errors:\n" + GL20.glGetShaderInfoLog(this.vertexShaderId, 250));

		GL20.glCompileShader(this.fragmentShaderId);

		System.out.println("Fragment Shader Errors:\n" + GL20.glGetShaderInfoLog(this.fragmentShaderId, 250));

		GL20.glAttachShader(this.programId, this.vertexShaderId);
		GL20.glAttachShader(this.programId, this.fragmentShaderId);

		GL20.glLinkProgram(this.programId);

		this.glGetUniformLocation();

		this.shaderCreated = true;
	}

	@Unique
	public void glGetUniformLocation() {
		this.camPos = GL20.glGetUniformLocation(this.programId, "u_CamPos");
		this.tex = GL20.glGetUniformLocation(this.programId, "u_TexId");
	}

	@Unique
	public void setupUniforms(float posX, float posY, float posZ) {
		GL20.glUniform1i(this.tex, 0);
		GL20.glUniform3f(this.camPos, posX, posY, posZ);
	}

	@Unique
	private static final String vertexShader =
			"  #version 110    																						\n" +
			"    																									\n" +
			"  varying vec4 color;																					\n" +
			"  varying vec2 v_TextureUV;																			\n" +
			"  uniform vec3 u_CamPos;          																		\n" +
			"     																									\n" +
			"  void main() {    																					\n" +
			"      vec4 pos = gl_ModelViewProjectionMatrix * (vec4(gl_Vertex.xyz - u_CamPos, gl_Vertex.w));	 		\n" +
			"      v_TextureUV = gl_MultiTexCoord0.st;   															\n" +
			"	   gl_Position = pos; 																				\n" +
			"	   color = gl_Color; 																				\n" +
			"  } 																									\n" +
			"    																									\n" +
			"      																									\n";

	@Unique
	private static final String fragmentShader =
			"   #version 110																			  		  \n" +
			"   																		  						  \n" +
			"   varying vec4 color;																				  \n" +
			"   varying vec2 v_TextureUV;																		  \n" +
			"  																									  \n" +
			"   uniform sampler2D u_TexId;															 		      \n" +
			"   																			  					  \n" +
			"   void main() {																			          \n" +
			"   	gl_FragColor = color * texture2D(u_TexId, v_TextureUV);							  \n" +
			"   }																			   					  \n" +
			"      																								  \n";

	@Unique
	private ChunkRenderer chunkRendererToUpdate;

	/**
	 * @author Safixo
	 * @reason Update renderers in our way.
	 */
	@Overwrite
	public boolean updateRenderers(ICamera camera) {
		final ChunkRenderer cr = this.chunkRendererToUpdate;

		if (cr != null) {
			cr.updateRenderer();
			cr.needsUpdate = false;
			this.chunkRendererToUpdate = null;
		}

		return true;
	}

	@Unique
	private final ObjectArrayList<ChunkRenderer> renderList = new ObjectArrayList<>();
//	@Unique
//	private final ObjectArrayList<ChunkRenderer> updateList = new ObjectArrayList<>();

	/**
	 * @author Safixo
	 * @reason Cull and feed renderer lists.
	 */
	@Overwrite
	public void clipRenderersByFrustum(CameraFrustum frustum, float partialTick) {
		this.renderList.clear();
//		this.updateList.clear();

		int camX = (int) this.mc.activeCamera.getX(partialTick);
		int camY = (int) this.mc.activeCamera.getY(partialTick);
		int camZ = (int) this.mc.activeCamera.getZ(partialTick);

		// Precompute some bitmasks for frustum culling.
		JomlFrustum.preComputeData();

		int distanceSquared = (int) FogHelper.getFogDistance();
		distanceSquared *= distanceSquared;

        for (ChunkRenderer cr : this.sortedChunkRenderers) {
            if (!cr.skipAllRenderPasses()) {
                IChunkRenderer icr = (IChunkRenderer) cr;

                boolean isVisible =
						isWithinRenderDistance(cr, camX, camY, camZ, distanceSquared)
                        && checkFrustum(cr, icr.getVertices(), camX, camY, camZ);

				// Instead of using Minecraft arrays/lists for rendering we feed our own.
				// This avoids a ton of overhead, serves us more control, and helps to
				// avoid Minecraft stupidity.
                if (isVisible) {
                    if (this.chunkRendererToUpdate == null && cr.needsUpdate) {
                        this.chunkRendererToUpdate = cr;
                    }

					// If the chunk faces "looking" at the camera are opaque and doesn't have vertices, we
					// assume the chunk/section is not visible. Isn't as good as occlusion culling in
					// their own but is like ~7% less chunks for free.
                    if (icr.getVertices() != 0 && isAnyFaceVisible(cr, camX, camY, camZ, icr.getFaces())) {
                        this.renderList.add(cr);
                    }
                }

                cr.isInFrustum = isVisible;
            }
        }
	}

	@Unique
	private static boolean isWithinRenderDistance(ChunkRenderer cr, int offsetX, int offsetY, int offsetZ, int distance) {
		int posX = cr.posXPlus - offsetX;
		int posY = cr.posYPlus - offsetY;
		int posZ = cr.posZPlus - offsetZ;

		return ((posX * posX) + (posY * posY) + (posZ * posZ)) <= distance;
	}

	@Unique
	private static boolean isAnyFaceVisible(ChunkRenderer cr, int offsetX, int offsetY, int offsetZ, int facesWithData) {
		int visibleFaces = getVisibleFaces(cr, offsetX, offsetY, offsetZ);

		return ((facesWithData ^ visibleFaces) & visibleFaces) != 0;
	}

	@Unique
	private static boolean isWithinFrustum(ChunkRenderer cr, int offsetX, int offsetY, int offsetZ) {
		// 1 is used as an epsilon.
		int minX = cr.posX - offsetX - 1;
		int minY = cr.posY - offsetY - 1;
		int minZ = cr.posZ - offsetZ - 1;

		int maxX = minX + 18;
		int maxY = minY + 18;
		int maxZ = minZ + 18;

		return JomlFrustum.testAabFasterInt(minX, minY, minZ, maxX, maxY, maxZ);
	}

	@Unique
	private static boolean checkFrustum(ChunkRenderer cr, int vertices, int offsetX, int offsetY, int offsetZ) {
		return vertices == 0 ? isWithinFrustumEmpty(cr, offsetX, offsetY, offsetZ) : isWithinFrustum(cr, offsetX, offsetY, offsetZ);
	}

	@Unique
	private static boolean isWithinFrustumEmpty(ChunkRenderer cr, int offsetX, int offsetY, int offsetZ) {
		// 1.5 is used as an epsilon
		float minX = cr.posXPlus - offsetX;
		float minY = cr.posYPlus - offsetY;
		float minZ = cr.posZPlus - offsetZ;

		return JomlFrustum.testAabSimpler(minX, minY, minZ);
	}

	@Unique
	private static int getVisibleFaces(ChunkRenderer cr, int camX, int camY, int camZ) {
		int posX = cr.posXPlus;
		int posY = cr.posYPlus;
		int posZ = cr.posZPlus;

		int visibleFaces = 0;

		visibleFaces |= BitwiseMath.greaterThan(camX + 2, posX) << GraphDirection.EAST;
		visibleFaces |= BitwiseMath.greaterThan(camY + 2, posY) << GraphDirection.UP;
		visibleFaces |= BitwiseMath.greaterThan(camZ + 2, posZ) << GraphDirection.SOUTH;

		visibleFaces |= BitwiseMath.lessThan(camX - 2, posX) << GraphDirection.WEST;
		visibleFaces |= BitwiseMath.lessThan(camY - 2, posY) << GraphDirection.DOWN;
		visibleFaces |= BitwiseMath.lessThan(camZ - 2, posZ) << GraphDirection.NORTH;

		return visibleFaces;
	}

	@Unique
	private void renderSolidTerrain(int index) {
		final ChunkRenderer sectionRender = this.renderList.get(index);
		final IChunkRenderer sectionRenderInterface = (IChunkRenderer) sectionRender;
		final GlVertexBuffer buffer = sectionRenderInterface.getSolidBuffer();

		if (!sectionRender.skipRenderPass[0]) {
			buffer.bindVAO();
			buffer.draw();
			this.renderersBeingRendered++;
		}
	}

	@Unique
	private void renderTranslucentTerrain(int index) {
		final ChunkRenderer sectionRender = this.renderList.get(index);
		final IChunkRenderer sectionRenderInterface = (IChunkRenderer) sectionRender;
		final GlVertexBuffer buffer = sectionRenderInterface.getTranslucentBuffer();

		if (!sectionRender.skipRenderPass[1]) {
			buffer.bindVAO();
			buffer.draw();
		}
	}
}

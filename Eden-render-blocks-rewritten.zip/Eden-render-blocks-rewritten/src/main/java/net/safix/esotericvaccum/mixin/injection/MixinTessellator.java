package net.safix.esotericvaccum.mixin.injection;

import net.minecraft.client.render.Tessellator;
import net.safix.esotericvaccum.client.rendering.VertexWriterManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.safix.esotericvaccum.client.rendering.VertexWriterManager.*;

/**
 * Extract vertex data from the tesselator to the VertexWriterManager when needed.
 */



@Mixin(value = Tessellator.class, remap = false)
public abstract class MixinTessellator {
	@Shadow private int color;
	@Shadow private boolean isDrawing;

	@Inject(method = "addVertexWithUV", at = @At("HEAD"), cancellable = true)
	public void passPositionAndUV(double x, double y, double z, double u, double v, CallbackInfo ci) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		if (!man.isDrawing()) {
			return;
		}

		man.setPos((float) x, (float) y, (float) z);
		man.setUV((float) u, (float) v);
		man.addVertex();

		ci.cancel();
	}

	@Inject(method = "setColorRGBA", at = @At("TAIL"))
	public void passColor(int r, int g, int b, int a, CallbackInfo ci) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		if (!man.isDrawing()) {
			return;
		}

		man.setColor(this.color);
	}


	@Inject(method = "setTranslation", at = @At("TAIL"))
	public void passTranslation(double x, double y, double z, CallbackInfo ci) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		if (!man.isDrawing()) {
			return;
		}

		man.setTranslation((float) x, (float) y, (float) z);
    }

	@Inject(method = "offsetTranslation", at = @At("TAIL"))
	public void addOffsetTranslation(float x, float y, float z, CallbackInfo ci) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		if (!man.isDrawing()) {
			return;
		}

		man.setTranslation(man.transX + x, man.transY + y, man.transZ + z);
	}

	@Inject(method = "draw", at = @At("TAIL"))
	public void manageDrawing(CallbackInfo ci) {
		VertexWriterManager man = VertexWriterManager.getCurrentInstance();

		if (!man.isDrawing()) {
			return;
		}

		this.isDrawing = false;
	}
}

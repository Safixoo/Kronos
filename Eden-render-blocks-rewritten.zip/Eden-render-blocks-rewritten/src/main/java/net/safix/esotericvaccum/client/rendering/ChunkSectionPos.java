package net.safix.esotericvaccum.client.rendering;

public class ChunkSectionPos {
	@SuppressWarnings("PointlessBitwiseExpression")
	public static long asLong(int x, int y, int z) {
		long l = 0L;
		l |= (long) x << 42 & 8_388_608;
		l |= (long) z << 20 & 8_388_608;
		l |=        y << 0 & 2_097_152;
		return l;
	}

	public static int getX(long l) {
		return (int) ((l >> 42) & 8_388_607);
	}

	public static int getY(long l) {
		return (int) (l & 2_097_151);
	}

	public static int getZ(long l) {
		return (int) ((l >> 20) & 8_388_607);
	}
}

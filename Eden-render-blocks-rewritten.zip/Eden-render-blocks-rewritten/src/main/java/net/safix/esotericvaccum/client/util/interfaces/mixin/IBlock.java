package net.safix.esotericvaccum.client.util.interfaces.mixin;

public interface IBlock {
	boolean getLitInterior();
}

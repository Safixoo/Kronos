package net.safix.esotericvaccum.client.rendering;

import net.minecraft.client.GLAllocation;
import net.safix.esotericvaccum.client.vertex.format.VertexFormat;
import org.checkerframework.checker.units.qual.C;

import java.nio.ByteBuffer;

/**
 * Pass the work from the Tessellator to this class when I want to manage the vertex data myself using a flag
 * and mixins to redirect data the vertex data from the entities and terrain mostly.
 * <p>
 * The point is to offer a better implementation of VBOs (as the current one is pretty naive and doesn't implement
 * it to terrain) and drawing and be able to mess with data more directly.
 */
public class VertexWriterManager {
	public float x, y, z;
	public float transX, transY, transZ;
	public float u, v;
	public int color;
	public int lighting;
	public int normal;

	private int capacity;
	private ByteBuffer vertexData;
	private VertexFormat vertexFormat;

	private int vertices = 0;
	private boolean isDrawing = false;
	private int offset = 0;

	public static VertexWriterManager EMPTY_INSTANCE = new VertexWriterManager(0);
	private static final VertexWriterManager DEFAULT_INSTANCE = new VertexWriterManager();
	private static VertexWriterManager CURRENT_INSTANCE;

	public VertexWriterManager(int capacity) {
		this.capacity = capacity;
		this.vertexData = GLAllocation.createDirectByteBuffer(this.capacity);
	}

	public VertexWriterManager() {
		this(65536);
	}

	public static VertexWriterManager getCurrentInstance() {
		if (CURRENT_INSTANCE != null) {
			return CURRENT_INSTANCE;
		}

		return DEFAULT_INSTANCE;
	}

	public static void setCurrentInstance(VertexWriterManager manager) {
		CURRENT_INSTANCE = manager;
	}

	public void startDrawing() {
		this.vertices = 0;
		this.offset = 0;
		this.isDrawing = true;
	}

	public void ensureCapacity(int offset) {
		if (this.offset + offset >= this.capacity) {
			this.grow();
		}
	}

	public void addVertexUnsafe() {
		this.vertexFormat.writeVertex(this.vertexData, this.offset);
		this.vertices++;
		this.offset += this.vertexFormat.getStride();
	}

	public void addVertex() {
		if (this.offset + this.vertexFormat.getStride() >= this.capacity) {
			this.grow();
		}

		this.vertexFormat.writeVertex(this.vertexData, this.offset);
		this.vertices++;
		this.offset += this.vertexFormat.getStride();
	}

	public void stopDrawing() {
		this.vertices = 0;
		this.offset = 0;
		this.isDrawing = false;
		this.vertexData.clear();
	}

	public void grow() {
		this.vertexData.position(0);
		int newCapacity = this.capacity * 2;
		ByteBuffer newBuffer = GLAllocation.createDirectByteBuffer(newCapacity);
		newBuffer.put(this.vertexData);
		this.vertexData = newBuffer;
		this.capacity = newCapacity;
	}

	// <------------------------->
	// Getters and setters below
	// <------------------------->

	// flag to know for what when pick up data from the tessellator.
	public boolean isDrawing() {
		return this.isDrawing;
	}

	public ByteBuffer getVertexData() {
		this.vertexData.position(0);
		this.vertexData.limit(offset);
		return this.vertexData;
	}

	public int getCapacity() {
		return this.capacity;
	}

	public int getVertices() {
		return this.vertices;
	}

	public void setPos(float X, float Y, float Z) {
		this.x = X;
		this.y = Y;
		this.z = Z;
	}

	public void setTranslation(float TRANS_X, float TRANS_Y, float TRANS_Z) {
		this.transX = TRANS_X;
		this.transY = TRANS_Y;
		this.transZ = TRANS_Z;
	}

	public void setUV(float U, float V) {
		this.u = U;
		this.v = V;
	}

	public void setUV(double U, double V) {
		this.u = (float) U;
		this.v = (float) V;
	}

	public void setColor(int COLOR) {
		this.color = COLOR;
	}

	public void setNormal(int NORMAL) {
		this.normal = NORMAL;
	}

	public void setLighting(int LIGHT) {
		this.lighting = LIGHT;
	}

	public void setVertexFormat(VertexFormat VERTEX_FORMAT) {
		this.vertexFormat = VERTEX_FORMAT;
	}
}
